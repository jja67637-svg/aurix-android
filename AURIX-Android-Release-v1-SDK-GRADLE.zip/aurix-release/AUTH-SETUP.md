# AURIX — konfiguracja logowania Google + WhatsApp

AURIX korzysta z Supabase Auth. Frontend obsługuje trzy metody:

- e-mail + hasło,
- Google OAuth,
- numer telefonu + jednorazowy kod przez WhatsApp.

## 1. Supabase

W `index.html` ustaw:

```js
window.AURIX_CONFIG = {
  apiBase: '',
  supabaseUrl: 'https://TWOJ-PROJEKT.supabase.co',
  supabaseAnonKey: 'TWOJ_PUBLISHABLE_KEY',
  auth: { google: true, whatsapp: true }
};
```

Używaj wyłącznie klucza publishable/anon w przeglądarce. Nigdy nie umieszczaj `service_role` w `index.html`.

## 2. Google

W Supabase: Authentication → Providers → Google włącz Google.

W Google Cloud utwórz OAuth Client ID typu Web application.
Dodaj domenę AURIX do Authorized JavaScript origins oraz callback Supabase pokazany w konfiguracji providera.

Przycisk `ZALOGUJ PRZEZ GOOGLE` korzysta bezpośrednio z `supabase.auth.signInWithOAuth({ provider: 'google' })`.

## 3. WhatsApp

W Supabase włącz Phone Auth i skonfiguruj dostawcę Twilio/Twilio Verify z kanałem WhatsApp.

AURIX wysyła OTP bezpośrednio przez Supabase:

```js
await supabase.auth.signInWithOtp({
  phone: '+48123456789',
  options: { channel: 'whatsapp' }
});
```

Kod jest weryfikowany przez:

```js
await supabase.auth.verifyOtp({
  phone: '+48123456789',
  token: '123456',
  type: 'sms'
});
```

Numer telefonu jest zawsze składany z wybranego kierunkowego kraju i numeru użytkownika.

## 4. Bezpieczeństwo

- nie przechowuj sekretów Google/Twilio w frontendzie,
- włącz CAPTCHA/rate limits dla OTP w produkcji,
- ogranicz redirect URLs do domen AURIX,
- włącz RLS dla danych profilu i ustawień użytkownika.
