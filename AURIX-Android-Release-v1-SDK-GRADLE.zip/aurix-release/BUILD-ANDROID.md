# AURIX — szybkie uruchomienie Android

## Wymagania

- Android Studio 2025.2.1 lub nowsze
- Android SDK Platform 36
- JDK 21
- dostęp do Google Maven i Maven Central

## Uruchomienie

1. Rozpakuj projekt.
2. W Android Studio wybierz **Open** i wskaż katalog `android/`.
3. Poczekaj na Gradle Sync.
4. Podłącz telefon z Androidem 8+ i włącz debugowanie USB.
5. Uruchom konfigurację `app`.

## APK

W Android Studio: **Build → Generate App Bundles or APKs → Generate APKs**.

Do Google Play użyj **Generate Signed Bundle / APK → Android App Bundle**.

## Capacitor

Kod webowy jest w `www/`. Native Android ma własny most JavaScript (`native-bridge.js`) oraz natywne komponenty Java.

Jeżeli chcesz później aktualizować projekt przez Capacitor CLI:

```bash
npm install
npx cap sync android
```

Następnie sprawdź, czy `android/app/src/main/assets/public/` zawiera aktualne pliki webowe.
