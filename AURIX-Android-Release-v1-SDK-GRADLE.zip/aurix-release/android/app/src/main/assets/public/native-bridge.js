/* AURIX native bridge. Browser/PWA safely falls back to web APIs. */
(function(){
  const n=window.AURIXNative;
  const native={
    available:!!n,
    call(name,...args){
      try{if(!n||typeof n[name]!=='function')return null;return n[name](...args)}catch(e){console.warn('[AURIX native]',name,e);return null}},
    json(name,...args){const v=this.call(name,...args);try{return typeof v==='string'?JSON.parse(v):v}catch{return null}},
    permissions(){return this.json('getPermissionStatus')||{}},
    requestPermissions(){return this.call('requestPermissions')},
    requestBackgroundLocation(){return this.call('requestBackgroundLocation')},
    startBackgroundLocation(){return this.call('startBackgroundLocation')},
    stopBackgroundLocation(){return this.call('stopBackgroundLocation')},
    setKeepScreenOn(v){return this.call('setKeepScreenOn',!!v)},
    playAlert(level,volume,distance){return this.call('playAlert',Number(level)||1,Number(volume)||.75,Number(distance)||999999)},
    speak(text,lang,volume){return this.call('speak',String(text||''),String(lang||'pl'),Number(volume)||.75)},
    vibrate(kind){return this.call('vibrate',String(kind||'alert'))},
    setAutoStart(v){return this.call('setAutoStart',!!v)},
    getAutoStart(){return !!this.call('getAutoStart')},
    getLastLocation(){return this.json('getLastLocation')},
    setDriveState(v){return this.call('setDriveState',!!v)},
    setCurrentAlert(label,distance,priority){return this.call('setCurrentAlert',String(label||''),Number(distance)||0,Number(priority)||0)},
    postAlertNotification(label,distance){return this.call('postAlertNotification',String(label||''),String(distance||''))},
    openAppSettings(){return this.call('openAppSettings')},
    openBatterySettings(){return this.call('openBatterySettings')},
    openAndroidAuto(){return this.call('openAndroidAuto')},
    isIgnoringBatteryOptimizations(){return !!this.call('isIgnoringBatteryOptimizations')}
  };
  window.AURIXNativeBridge=native;
  window.AURIXNativeLocation=function(raw){
    try{
      const p=typeof raw==='string'?JSON.parse(raw):raw;
      if(!p||!Number.isFinite(Number(p.lat))||!Number.isFinite(Number(p.lon)))return;
      const pos={coords:{latitude:Number(p.lat),longitude:Number(p.lon),accuracy:Number(p.accuracy)||50,speed:Number.isFinite(Number(p.speed))?Number(p.speed):null,heading:Number.isFinite(Number(p.heading))?Number(p.heading):null}};
      if(typeof window.updatePosition==='function')window.updatePosition(pos,false);
    }catch(e){}
  };
})();
