const REPORT_TYPES={
 accident:{label:'Wypadek',icon:'🚨',color:'#ff3b30',priority:4},
 police:{label:'Policja / kontrola',icon:'🚓',color:'#2979ff',priority:3},
 camera:{label:'Fotoradar',icon:'📷',color:'#8e44ff',priority:3},
 roadworks:{label:'Roboty drogowe',icon:'🚧',color:'#ff9500',priority:2},
 traffic:{label:'Korek',icon:'🚦',color:'#ffd60a',priority:2},
 vehicle:{label:'Pojazd / awaria',icon:'🚗',color:'#00c7be',priority:3},
 road:{label:'Uszkodzona droga',icon:'🕳️',color:'#a66a3f',priority:2},
 animal:{label:'Zwierzę na drodze',icon:'🐗',color:'#34c759',priority:3},
 weather:{label:'Warunki pogodowe',icon:'🌧️',color:'#32ade6',priority:2},
 other:{label:'Inne zagrożenie',icon:'⚠️',color:'#ff2d55',priority:3}
};
const LANGUAGES={pl:'Polski',en:'English',nl:'Nederlands',de:'Deutsch',lt:'Lietuvių',cs:'Čeština',sk:'Slovenčina',uk:'Українська',ru:'Русский',it:'Italiano',es:'Español'};

const I18N={
 pl:{'EUROPEAN DRIVER NETWORK':'EUROPEAN DRIVER NETWORK','Jedź świadomie.':'Jedź świadomie.','Alerty kierowców, fotoradary i wirtualne CB — w jednym miejscu.':'Alerty kierowców, fotoradary i wirtualne CB — w jednym miejscu.','ROZPOCZNIJ JAZDĘ':'ROZPOCZNIJ JAZDĘ','GPS + alerty w pobliżu':'GPS + alerty w pobliżu','alertów':'alertów','fotoradarów':'fotoradarów','kierowców CB':'kierowców CB','Aktywne zgłoszenia':'Aktywne zgłoszenia','MAPA →':'MAPA →','POTRZEBUJĘ POMOCY':'POTRZEBUJĘ POMOCY','Powiadom kierowców w pobliżu':'Powiadom kierowców w pobliżu','MAPA':'MAPA','TRYB JAZDY AKTYWNY':'TRYB JAZDY AKTYWNY','PRĘDKOŚĆ':'PRĘDKOŚĆ','Brak alertu przed Tobą':'Brak alertu przed Tobą','ZGŁOŚ':'ZGŁOŚ','jedno kliknięcie':'jedno kliknięcie','Wyślij lokalizację kierowcom w pobliżu':'Wyślij lokalizację kierowcom w pobliżu','ZAKOŃCZ TRYB JAZDY':'ZAKOŃCZ TRYB JAZDY','WIRTUALNE CB':'WIRTUALNE CB','ONLINE':'ONLINE','KANAŁ':'KANAŁ','KIEROWCY W ZASIĘGU':'KIEROWCY W ZASIĘGU','ZASIĘG ODSŁUCHU':'ZASIĘG ODSŁUCHU','PRZYTRZYMAJ, ABY MÓWIĆ':'PRZYTRZYMAJ, ABY MÓWIĆ','NASŁUCH':'NASŁUCH','MÓJ KIERUNEK':'MÓJ KIERUNEK','Ostatnie transmisje':'Ostatnie transmisje','Brak transmisji w tej chwili.':'Brak transmisji w tej chwili.','LIVE':'LIVE','Alerty':'Alerty','Alerty przed Tobą':'Alerty przed Tobą','Brak alertów przed Tobą':'Brak alertów przed Tobą','ODŚWIEŻ':'ODŚWIEŻ','GŁOŚNOŚĆ ALERTÓW':'GŁOŚNOŚĆ ALERTÓW','Dotyczy sygnału i komunikatów głosowych.':'Dotyczy sygnału i komunikatów głosowych.','KOMUNIKATY GŁOSOWE':'KOMUNIKATY GŁOSOWE','Lokalizacja':'Lokalizacja','Nieaktywna':'Nieaktywna','Powiadomienia':'Powiadomienia','Ustawienia':'Ustawienia','Mikrofon':'Mikrofon','Opcjonalny':'Opcjonalny','Język aplikacji':'Język aplikacji','Prywatność':'Prywatność','JĘZYK APLIKACJI':'JĘZYK APLIKACJI','POTRZEBUJĘ POMOCY — WYBIERZ PROBLEM':'POTRZEBUJĘ POMOCY — WYBIERZ PROBLEM','Wybierz problem. AURIX pobierze świeżą pozycję GPS i pokaże wezwanie kierowcom w pobliżu.':'Wybierz problem. AURIX pobierze świeżą pozycję GPS i pokaże wezwanie kierowcom w pobliżu.','ZGŁOŚ ZDARZENIE':'ZGŁOŚ ZDARZENIE','ANULUJ':'ANULUJ','WYBIERZ KANAŁ':'WYBIERZ KANAŁ','ZEZWÓL NA GPS':'ZEZWÓL NA GPS','Później':'Później','Wszystkie':'Wszystkie'},
 en:{'Jedź świadomie.':'Drive aware.','Alerty kierowców, fotoradary i wirtualne CB — w jednym miejscu.':'Driver alerts, speed cameras and virtual CB — in one place.','ROZPOCZNIJ JAZDĘ':'START DRIVE','GPS + alerty w pobliżu':'GPS + nearby alerts','alertów':'alerts','fotoradarów':'speed cameras','kierowców CB':'CB drivers','Aktywne zgłoszenia':'Active reports','MAPA →':'MAP →','POTRZEBUJĘ POMOCY':'I NEED HELP','Powiadom kierowców w pobliżu':'Alert nearby drivers','MAPA':'MAP','TRYB JAZDY AKTYWNY':'DRIVE MODE ACTIVE','PRĘDKOŚĆ':'SPEED','Brak alertu przed Tobą':'No alert ahead','ZGŁOŚ':'REPORT','jedno kliknięcie':'one tap','Wyślij lokalizację kierowcom w pobliżu':'Send location to nearby drivers','ZAKOŃCZ TRYB JAZDY':'END DRIVE MODE','WIRTUALNE CB':'VIRTUAL CB','ONLINE':'ONLINE','KANAŁ':'CHANNEL','KIEROWCY W ZASIĘGU':'DRIVERS IN RANGE','ZASIĘG ODSŁUCHU':'LISTEN RANGE','PRZYTRZYMAJ, ABY MÓWIĆ':'HOLD TO TALK','NASŁUCH':'LISTEN','MÓJ KIERUNEK':'MY DIRECTION','Ostatnie transmisje':'Recent transmissions','Brak transmisji w tej chwili.':'No transmissions right now.','LIVE':'LIVE','Alerty':'Alerts','Alerty przed Tobą':'Alerts ahead','Brak alertów przed Tobą':'No alerts ahead','ODŚWIEŻ':'REFRESH','GŁOŚNOŚĆ ALERTÓW':'ALERT VOLUME','Dotyczy sygnału i komunikatów głosowych.':'Applies to sounds and voice alerts.','KOMUNIKATY GŁOSOWE':'VOICE ALERTS','Lokalizacja':'Location','Nieaktywna':'Inactive','Powiadomienia':'Notifications','Ustawienia':'Settings','Mikrofon':'Microphone','Opcjonalny':'Optional','Język aplikacji':'App language','Prywatność':'Privacy','JĘZYK APLIKACJI':'APP LANGUAGE','POTRZEBUJĘ POMOCY — WYBIERZ PROBLEM':'I NEED HELP — SELECT A PROBLEM','Wybierz problem. AURIX pobierze świeżą pozycję GPS i pokaże wezwanie kierowcom w pobliżu.':'Choose a problem. AURIX will get your current GPS position and show the request to nearby drivers.','ZGŁOŚ ZDARZENIE':'REPORT AN EVENT','ANULUJ':'CANCEL','WYBIERZ KANAŁ':'SELECT CHANNEL','ZEZWÓL NA GPS':'ALLOW GPS','Później':'Later','Wszystkie':'All'},
 nl:{'Jedź świadomie.':'Rijd bewust.','Alerty kierowców, fotoradary i wirtualne CB — w jednym miejscu.':'Bestuurderswaarschuwingen, flitsers en virtuele CB — op één plek.','ROZPOCZNIJ JAZDĘ':'START RIT','POTRZEBUJĘ POMOCY':'IK HEB HULP NODIG','MAPA':'KAART','ZGŁOŚ':'MELDEN','Alerty':'Meldingen','Alerty przed Tobą':'Meldingen voor je','Brak alertów przed Tobą':'Geen waarschuwingen voor je','Język aplikacji':'App-taal','Wszystkie':'Alle'},
 de:{'Jedź świadomie.':'Fahre bewusst.','Alerty kierowców, fotoradary i wirtualne CB — w jednym miejscu.':'Fahrerwarnungen, Blitzer und virtuelles CB — an einem Ort.','ROZPOCZNIJ JAZDĘ':'FAHRT STARTEN','POTRZEBUJĘ POMOCY':'ICH BRAUCHE HILFE','MAPA':'KARTE','ZGŁOŚ':'MELDEN','Alerty':'Warnungen','Język aplikacji':'App-Sprache','Wszystkie':'Alle'},
 lt:{'Jedź świadomie.':'Važiuokite sąmoningai.','POTRZEBUJĘ POMOCY':'MAN REIKIA PAGALBOS','MAPA':'ŽEMĖLAPIS','ZGŁOŚ':'PRANEŠTI','Alerty':'Įspėjimai','Alerty przed Tobą':'Įspėjimai prieš jus','Brak alertów przed Tobą':'Įspėjimų prieš jus nėra','Język aplikacji':'Programėlės kalba','Wszystkie':'Visi'},
 cs:{'Jedź świadomie.':'Jeďte vědomě.','POTRZEBUJĘ POMOCY':'POTŘEBUJI POMOC','MAPA':'MAPA','ZGŁOŚ':'NAHLÁSIT','Alerty':'Upozornění','Alerty przed Tobą':'Upozornění před vámi','Brak alertów przed Tobą':'Žádná upozornění před vámi','Język aplikacji':'Jazyk aplikace','Wszystkie':'Vše'},
 sk:{'Jedź świadomie.':'Jazdite vedome.','POTRZEBUJĘ POMOCY':'POTREBUJEM POMOC','MAPA':'MAPA','ZGŁOŚ':'NAHLÁSIŤ','Alerty':'Upozornenia','Alerty przed Tobą':'Upozornenia pred vami','Brak alertów przed Tobą':'Žiadne upozornenia pred vami','Język aplikacji':'Jazyk aplikácie','Wszystkie':'Všetky'},
 uk:{'Jedź świadomie.':'Керуйте уважно.','POTRZEBUJĘ POMOCY':'ПОТРІБНА ДОПОМОГА','MAPA':'КАРТА','ZGŁOŚ':'ПОВІДОМИТИ','Alerty':'СПОВІЩЕННЯ','Język aplikacji':'Мова застосунку','Wszystkie':'Усі'},
 ru:{'Jedź świadomie.':'Ведите внимательно.','POTRZEBUJĘ POMOCY':'НУЖНА ПОМОЩЬ','MAPA':'КАРТА','ZGŁOŚ':'СООБЩИТЬ','Alerty':'ОПОВЕЩЕНИЯ','Język aplikacji':'Язык приложения','Wszystkie':'Все'},
 it:{'Jedź świadomie.':'Guida consapevolmente.','POTRZEBUJĘ POMOCY':'HO BISOGNO DI AIUTO','MAPA':'MAPPA','ZGŁOŚ':'SEGNALA','Alerty':'AVVISI','Język aplikacji':'Lingua dell’app','Wszystkie':'Tutti'},
 es:{'Jedź świadomie.':'Conduce con atención.','POTRZEBUJĘ POMOCY':'NECESITO AYUDA','MAPA':'MAPA','ZGŁOŚ':'REPORTAR','Alerty':'ALERTAS','Język aplikacji':'Idioma de la app','Wszystkie':'Todos'}
};const I18N_EXTRA={
pl:{'HOME':'HOME','CB':'CB','PROFIL':'PROFIL','status konta':'status konta','ALERT PRZED TOBĄ':'ALERT PRZED TOBĄ','Brak krytycznych alertów w pobliżu':'Brak krytycznych alertów w pobliżu','POTWIERDŹ':'POTWIERDŹ','ODWOŁAJ':'ODWOŁAJ','POTWIERDZONE':'POTWIERDZONE','ODWOŁANE':'ODWOŁANE','Brak aktywnych zgłoszeń.':'Brak aktywnych zgłoszeń.','Brak aktywnych zgłoszeń w pobliżu.':'Brak aktywnych zgłoszeń w pobliżu.','FOTORADAR':'FOTORADAR','Limit':'Limit','Brak wezwań pomocy w pobliżu.':'Brak wezwań pomocy w pobliżu.','POBIERAM LOKALIZACJĘ…':'POBIERAM LOKALIZACJĘ…','JAZDA AKTYWNA':'JAZDA AKTYWNA','Alerty są aktywne':'Alerty są aktywne','Tryb jazdy aktywny':'Tryb jazdy aktywny','ZAKOŃCZ TRYB JAZDY':'ZAKOŃCZ TRYB JAZDY','Zgłoszenie minięte':'Zgłoszenie minięte','Dane odświeżone':'Dane odświeżone','Kod został wysłany przez WhatsApp':'Kod został wysłany przez WhatsApp','Nieprawidłowy lub wygasły kod':'Nieprawidłowy lub wygasły kod','Zalogowano przez WhatsApp':'Zalogowano przez WhatsApp','Nie udało się zweryfikować kodu':'Nie udało się zweryfikować kodu','Wylogowano':'Wylogowano','Podaj numer telefonu i kod':'Podaj numer telefonu i kod','Podaj email i hasło (min. 6 znaków)':'Podaj email i hasło (min. 6 znaków)','Konto utworzone':'Konto utworzone','Zalogowano':'Zalogowano','Sprawdź email i potwierdź konto':'Sprawdź email i potwierdź konto','Zaloguj się, aby dodać zdjęcie':'Zaloguj się, aby dodać zdjęcie','Wybierz zdjęcie':'Wybierz zdjęcie','Zdjęcie może mieć maks. 4 MB':'Zdjęcie może mieć maks. 4 MB','Zdjęcie profilowe zapisane':'Zdjęcie profilowe zapisane','Nie udało się pobrać aktualnej pozycji GPS — zgłoszenie nie zostało zapisane':'Nie udało się pobrać aktualnej pozycji GPS — zgłoszenie nie zostało zapisane','Włącz GPS, aby wysłać wezwanie pomocy':'Włącz GPS, aby wysłać wezwanie pomocy','Lokalizacja włączona':'Lokalizacja włączona','Później':'Później','Lokalizację możesz włączyć później w Profilu':'Lokalizację możesz włączyć później w Profilu','Dostęp do lokalizacji został odrzucony. Włącz go w ustawieniach telefonu.':'Dostęp do lokalizacji został odrzucony. Włącz go w ustawieniach telefonu.','Nie udało się pobrać lokalizacji. Spróbuj ponownie.':'Nie udało się pobrać lokalizacji. Spróbuj ponownie.','Ta przeglądarka nie obsługuje lokalizacji GPS':'Ta przeglądarka nie obsługuje lokalizacji GPS','Nie udało się wysłać kodu WhatsApp':'Nie udało się wysłać kodu WhatsApp','Brak połączenia z serwerem logowania WhatsApp':'Brak połączenia z serwerem logowania WhatsApp','Najpierw skonfiguruj Supabase':'Najpierw skonfiguruj Supabase','Prywatność: dane lokalizacyjne są używane tylko do funkcji drogowych':'Prywatność: dane lokalizacyjne są używane tylko do funkcji drogowych','Mikrofon aktywny':'Mikrofon aktywny','Mikrofon nie został udostępniony':'Mikrofon nie został udostępniony','Powiadomienia nie są dostępne':'Powiadomienia nie są dostępne','Język aplikacji:':'Język aplikacji:','Kanał':'Kanał','Kanał aktywny':'Kanał aktywny','Uwaga.':'Uwaga.','kontrola prędkości':'kontrola prędkości','wypadek':'wypadek','fotoradar':'fotoradar','roboty drogowe':'roboty drogowe','korek':'korek','pojazd lub awaria':'pojazd lub awaria','uszkodzona droga':'uszkodzona droga','zwierzę na drodze':'zwierzę na drodze','trudne warunki pogodowe':'trudne warunki pogodowe','inne zagrożenie':'inne zagrożenie'},
en:{'HOME':'HOME','CB':'CB','PROFIL':'PROFILE','status konta':'account status','ALERT PRZED TOBĄ':'ALERT AHEAD','Brak krytycznych alertów w pobliżu':'No critical alerts nearby','POTWIERDŹ':'CONFIRM','ODWOŁAJ':'DISMISS','POTWIERDZONE':'CONFIRMED','ODWOŁANE':'DISMISSED','Brak aktywnych zgłoszeń.':'No active reports.','Brak aktywnych zgłoszeń w pobliżu.':'No active reports nearby.','FOTORADAR':'SPEED CAMERA','Limit':'Limit','Brak wezwań pomocy w pobliżu.':'No help requests nearby.','POBIERAM LOKALIZACJĘ…':'GETTING LOCATION…','JAZDA AKTYWNA':'DRIVE ACTIVE','Alerty są aktywne':'Alerts are active','Tryb jazdy aktywny':'Drive mode active','Zgłoszenie minięte':'Report passed','Dane odświeżone':'Data refreshed','Kod został wysłany przez WhatsApp':'Code sent via WhatsApp','Nieprawidłowy lub wygasły kod':'Invalid or expired code','Zalogowano przez WhatsApp':'Logged in with WhatsApp','Nie udało się zweryfikować kodu':'Could not verify code','Wylogowano':'Logged out','Podaj numer telefonu i kod':'Enter phone number and code','Podaj email i hasło (min. 6 znaków)':'Enter email and password (min. 6 characters)','Konto utworzone':'Account created','Zalogowano':'Logged in','Sprawdź email i potwierdź konto':'Check your email and confirm your account','Zaloguj się, aby dodać zdjęcie':'Log in to add a photo','Wybierz zdjęcie':'Choose a photo','Zdjęcie może mieć maks. 4 MB':'Photo can be up to 4 MB','Zdjęcie profilowe zapisane':'Profile photo saved','Nie udało się pobrać aktualnej pozycji GPS — zgłoszenie nie zostało zapisane':'Could not get your current GPS position — report was not saved','Włącz GPS, aby wysłać wezwanie pomocy':'Enable GPS to send a help request','Lokalizacja włączona':'Location enabled','Lokalizację możesz włączyć później w Profilu':'You can enable location later in Profile','Dostęp do lokalizacji został odrzucony. Włącz go w ustawieniach telefonu.':'Location access was denied. Enable it in phone settings.','Nie udało się pobrać lokalizacji. Spróbuj ponownie.':'Could not get location. Try again.','Ta przeglądarka nie obsługuje lokalizacji GPS':'This browser does not support GPS location','Nie udało się wysłać kodu WhatsApp':'Could not send WhatsApp code','Brak połączenia z serwerem logowania WhatsApp':'No connection to WhatsApp login server','Najpierw skonfiguruj Supabase':'Configure Supabase first','Prywatność: dane lokalizacyjne są używane tylko do funkcji drogowych':'Privacy: location data is used only for driving features','Mikrofon aktywny':'Microphone active','Mikrofon nie został udostępniony':'Microphone access was not granted','Powiadomienia nie są dostępne':'Notifications are not available','Język aplikacji:':'App language:','Kanał':'Channel','Kanał aktywny':'Channel active','Uwaga.':'Attention.','kontrola prędkości':'speed control','wypadek':'accident','fotoradar':'speed camera','roboty drogowe':'roadworks','korek':'traffic jam','pojazd lub awaria':'vehicle or breakdown','uszkodzona droga':'damaged road','zwierzę na drodze':'animal on the road','trudne warunki pogodowe':'difficult weather conditions','inne zagrożenie':'other hazard'},
nl:{'HOME':'HOME','CB':'CB','PROFIL':'PROFIEL','status konta':'accountstatus','ALERT PRZED TOBĄ':'WAARSCHUWING VOOR JE','Brak krytycznych alertów w pobliżu':'Geen kritieke waarschuwingen in de buurt','POTWIERDŹ':'BEVESTIGEN','ODWOŁAJ':'AFWIJZEN','POTWIERDZONE':'BEVESTIGD','ODWOŁANE':'AFGEWEZEN','Brak aktywnych zgłoszeń.':'Geen actieve meldingen.','Brak aktywnych zgłoszeń w pobliżu.':'Geen actieve meldingen in de buurt.','FOTORADAR':'FLITSPAAL','Brak wezwań pomocy w pobliżu.':'Geen hulpverzoeken in de buurt.','POBIERAM LOKALIZACJĘ…':'LOCATIE OPHALEN…','JAZDA AKTYWNA':'RIT ACTIEF','Alerty są aktywne':'Waarschuwingen zijn actief','Tryb jazdy aktywny':'Ritmodus actief','Zgłoszenie minięte':'Melding gepasseerd','Dane odświeżone':'Gegevens vernieuwd','Kod został wysłany przez WhatsApp':'Code verzonden via WhatsApp','Nieprawidłowy lub wygasły kod':'Ongeldige of verlopen code','Zalogowano przez WhatsApp':'Ingelogd met WhatsApp','Nie udało się zweryfikować kodu':'Code kon niet worden geverifieerd','Wylogowano':'Uitgelogd','Podaj numer telefonu i kod':'Voer telefoonnummer en code in','Podaj email i hasło (min. 6 znaków)':'Voer e-mail en wachtwoord in (min. 6 tekens)','Konto utworzone':'Account aangemaakt','Zalogowano':'Ingelogd','Sprawdź email i potwierdź konto':'Controleer je e-mail en bevestig je account','Zaloguj się, aby dodać zdjęcie':'Log in om een foto toe te voegen','Wybierz zdjęcie':'Kies een foto','Zdjęcie może mieć maks. 4 MB':'Foto mag maximaal 4 MB zijn','Zdjęcie profilowe zapisane':'Profielfoto opgeslagen','Nie udało się pobrać aktualnej pozycji GPS — zgłoszenie nie zostało zapisane':'Huidige GPS-locatie kon niet worden opgehaald — melding niet opgeslagen','Włącz GPS, aby wysłać wezwanie pomocy':'Schakel GPS in om hulp te vragen','Lokalizacja włączona':'Locatie ingeschakeld','Lokalizację możesz włączyć później w Profilu':'Je kunt locatie later in Profiel inschakelen','Dostęp do lokalizacji został odrzucony. Włącz go w ustawieniach telefonu.':'Locatietoegang geweigerd. Schakel dit in bij telefooninstellingen.','Nie udało się pobrać lokalizacji. Spróbuj ponownie.':'Locatie ophalen mislukt. Probeer opnieuw.','Ta przeglądarka nie obsługuje lokalizacji GPS':'Deze browser ondersteunt geen GPS-locatie','Nie udało się wysłać kodu WhatsApp':'WhatsApp-code kon niet worden verzonden','Brak połączenia z serwerem logowania WhatsApp':'Geen verbinding met WhatsApp-inlogserver','Najpierw skonfiguruj Supabase':'Configureer eerst Supabase','Prywatność: dane lokalizacyjne są używane tylko do funkcji drogowych':'Privacy: locatiegegevens worden alleen voor rijfuncties gebruikt','Mikrofon aktywny':'Microfoon actief','Mikrofon nie został udostępniony':'Microfoontoegang niet verleend','Powiadomienia nie są dostępne':'Meldingen zijn niet beschikbaar','Język aplikacji:':'App-taal:','Kanał':'Kanaal','Kanał aktywny':'Kanaal actief','Uwaga.':'Let op.','kontrola prędkości':'snelheidscontrole','wypadek':'ongeval','fotoradar':'flitspaal','roboty drogowe':'wegwerkzaamheden','korek':'file','pojazd lub awaria':'voertuig of pech','uszkodzona droga':'beschadigde weg','zwierzę na drodze':'dier op de weg','trudne warunki pogodowe':'slechte weersomstandigheden','inne zagrożenie':'ander gevaar'}
};
const VOICE_LABELS={
pl:{police:'kontrola prędkości',accident:'wypadek',camera:'fotoradar',roadworks:'roboty drogowe',traffic:'korek',vehicle:'pojazd lub awaria',road:'uszkodzona droga',animal:'zwierzę na drodze',weather:'trudne warunki pogodowe',other:'inne zagrożenie'},
en:{police:'speed control',accident:'accident',camera:'speed camera',roadworks:'roadworks',traffic:'traffic jam',vehicle:'vehicle or breakdown',road:'damaged road',animal:'animal on the road',weather:'difficult weather conditions',other:'other hazard'},
nl:{police:'snelheidscontrole',accident:'ongeval',camera:'flitspaal',roadworks:'wegwerkzaamheden',traffic:'file',vehicle:'voertuig of pech',road:'beschadigde weg',animal:'dier op de weg',weather:'slechte weersomstandigheden',other:'ander gevaar'},
de:{police:'Geschwindigkeitskontrolle',accident:'Unfall',camera:'Blitzer',roadworks:'Baustelle',traffic:'Stau',vehicle:'Fahrzeug oder Panne',road:'beschädigte Straße',animal:'Tier auf der Straße',weather:'schwierige Wetterbedingungen',other:'andere Gefahr'},
lt:{police:'greičio kontrolė',accident:'avarija',camera:'greičio kamera',roadworks:'kelio darbai',traffic:'eismo spūstis',vehicle:'transporto priemonė arba gedimas',road:'sugadintas kelias',animal:'gyvūnas kelyje',weather:'sudėtingos oro sąlygos',other:'kitas pavojus'},
cs:{police:'kontrola rychlosti',accident:'nehoda',camera:'radar',roadworks:'práce na silnici',traffic:'dopravní zácpa',vehicle:'vozidlo nebo porucha',road:'poškozená silnice',animal:'zvíře na silnici',weather:'špatné povětrnostní podmínky',other:'jiné nebezpečí'},
sk:{police:'kontrola rýchlosti',accident:'nehoda',camera:'radar',roadworks:'práce na ceste',traffic:'dopravná zápcha',vehicle:'vozidlo alebo porucha',road:'poškodená cesta',animal:'zviera na ceste',weather:'zlé poveternostné podmienky',other:'iné nebezpečenstvo'},
uk:{police:'контроль швидкості',accident:'аварія',camera:'камера швидкості',roadworks:'дорожні роботи',traffic:'затори',vehicle:'автомобіль або поломка',road:'пошкоджена дорога',animal:'тварина на дорозі',weather:'складні погодні умови',other:'інша небезпека'},
ru:{police:'контроль скорости',accident:'авария',camera:'камера скорости',roadworks:'дорожные работы',traffic:'пробка',vehicle:'автомобиль или поломка',road:'повреждённая дорога',animal:'животное на дороге',weather:'сложные погодные условия',other:'другая опасность'},
it:{police:'controllo della velocità',accident:'incidente',camera:'autovelox',roadworks:'lavori stradali',traffic:'coda',vehicle:'veicolo o guasto',road:'strada danneggiata',animal:'animale sulla strada',weather:'condizioni meteo difficili',other:'altro pericolo'},
es:{police:'control de velocidad',accident:'accidente',camera:'radar',roadworks:'obras',traffic:'atasco',vehicle:'vehículo o avería',road:'carretera dañada',animal:'animal en la carretera',weather:'condiciones meteorológicas difíciles',other:'otro peligro'}
};
Object.entries(I18N_EXTRA).forEach(([lang,dict])=>Object.assign(I18N[lang]||{},dict));
const NATIVE_I18N={
 'FUNKCJE ANDROID':{pl:'FUNKCJE ANDROID',en:'ANDROID FEATURES'},
 'GPS w tle':{pl:'GPS w tle',en:'Background GPS'},
 'Powiadomienia systemowe':{pl:'Powiadomienia systemowe',en:'System notifications'},
 'Ekran podczas jazdy':{pl:'Ekran podczas jazdy',en:'Keep screen on while driving'},
 'Natywne audio':{pl:'Natywne audio',en:'Native audio'},
 'Wibracje alertów':{pl:'Wibracje alertów',en:'Alert haptics'},
 'GPS po starcie aplikacji':{pl:'GPS po starcie aplikacji',en:'Start GPS with app'},
 'Android Auto':{pl:'Android Auto',en:'Android Auto'},
 'Uprawnienia Androida':{pl:'Uprawnienia Androida',en:'Android permissions'},
 'Lokalizacja, mikrofon, powiadomienia':{pl:'Lokalizacja, mikrofon, powiadomienia',en:'Location, microphone, notifications'},
 'Aktywne':{pl:'Aktywne',en:'Enabled'},
 'Wyłączone':{pl:'Wyłączone',en:'Disabled'},
 'Obsługa przygotowana':{pl:'Obsługa przygotowana',en:'Support ready'},
 'Zawsze zezwalaj':{pl:'Zawsze zezwalaj',en:'Allow all the time'},
 'Zarządzaj uprawnieniem mikrofonu w Androidzie':{pl:'Zarządzaj uprawnieniem mikrofonu w Androidzie',en:'Manage microphone permission in Android'},
 'Włącz „Zawsze zezwalaj” dla lokalizacji, jeśli Android o to poprosi.':{pl:'Włącz „Zawsze zezwalaj” dla lokalizacji, jeśli Android o to poprosi.',en:'Choose “Allow all the time” for location if Android asks.'}
};
Object.entries(NATIVE_I18N).forEach(([key,langs])=>Object.entries(langs).forEach(([lang,val])=>{if(I18N[lang])I18N[lang][key]=val;}));
const I18N_UI_EXTRA={"de": {"EUROPEAN DRIVER NETWORK": "EUROPÄISCHES FAHRER-NETZWERK", "GPS + alerty w pobliżu": "GPS + Warnungen in der Nähe", "alertów": "Warnungen", "fotoradarów": "Blitzer", "kierowców CB": "CB-Fahrer", "Aktywne zgłoszenia": "Aktive Meldungen", "MAPA →": "KARTE →", "Powiadom kierowców w pobliżu": "Fahrer in der Nähe warnen", "TRYB JAZDY AKTYWNY": "FAHRMODUS AKTIV", "PRĘDKOŚĆ": "GESCHWINDIGKEIT", "Brak alertu przed Tobą": "Keine Warnung vor dir", "jedno kliknięcie": "ein Fingertipp", "Wyślij lokalizację kierowcom w pobliżu": "Standort an Fahrer in der Nähe senden", "ZAKOŃCZ TRYB JAZDY": "FAHRMODUS BEENDEN", "WIRTUALNE CB": "VIRTUELLES CB", "ONLINE": "ONLINE", "KANAŁ": "KANAL", "KIEROWCY W ZASIĘGU": "FAHRER IN REICHWEITE", "ZASIĘG ODSŁUCHU": "HÖRREICHWEITE", "PRZYTRZYMAJ, ABY MÓWIĆ": "ZUM SPRECHEN GEDRÜCKT HALTEN", "NASŁUCH": "MITHÖREN", "MÓJ KIERUNEK": "MEINE RICHTUNG", "Ostatnie transmisje": "Letzte Übertragungen", "Brak transmisji w tej chwili.": "Derzeit keine Übertragungen.", "LIVE": "LIVE", "ODŚWIEŻ": "AKTUALISIEREN", "Kierowca AURIX": "AURIX-Fahrer", "Profil lokalny": "Lokales Profil", "przejechane z aktywną AURIX": "mit AURIX gefahren", "NIEZALOGOWANY": "NICHT ANGEMELDET", "ZALOGOWANY": "ANGEMELDET", "GŁOŚNOŚĆ ALERTÓW": "WARNLAUTSTÄRKE", "Dotyczy sygnału i komunikatów głosowych.": "Gilt für Signale und Sprachwarnungen.", "KOMUNIKATY GŁOSOWE": "SPRACHWARNUNGEN", "Lokalizacja": "Standort", "Nieaktywna": "Inaktiv", "Powiadomienia": "Benachrichtigungen", "Ustawienia": "Einstellungen", "Mikrofon": "Mikrofon", "Opcjonalny": "Optional", "Język aplikacji": "App-Sprache", "Prywatność": "Datenschutz", "ZDJĘCIE PROFILOWE": "PROFILBILD", "NAZWA UŻYTKOWNIKA": "BENUTZERNAME", "Zmiany profilu zapisują się automatycznie.": "Profiländerungen werden automatisch gespeichert.", "Nie zalogowano": "Nicht angemeldet", "LOGOWANIE": "ANMELDUNG", "EMAIL": "E-MAIL", "HASŁO": "PASSWORT", "Zaloguj się": "Anmelden", "Utwórz konto": "Konto erstellen", "KONTYNUUJ E-MAIL": "MIT E-MAIL FORTFAHREN", "ZALOGUJ PRZEZ GOOGLE": "MIT GOOGLE ANMELDEN", "LUB TELEFON": "ODER TELEFON", "WYŚLIJ KOD PRZEZ WHATSAPP": "CODE ÜBER WHATSAPP SENDEN", "KOD WHATSAPP": "WHATSAPP-CODE", "ZALOGUJ KODEM": "MIT CODE ANMELDEN", "JĘZYK APLIKACJI": "APP-SPRACHE", "POTRZEBUJĘ POMOCY — WYBIERZ PROBLEM": "ICH BRAUCHE HILFE — PROBLEM AUSWÄHLEN", "Wybierz problem. AURIX pobierze świeżą pozycję GPS i pokaże wezwanie kierowcom w pobliżu.": "Wähle ein Problem. AURIX ermittelt deine aktuelle GPS-Position und zeigt die Anfrage Fahrern in der Nähe.", "ZGŁOŚ ZDARZENIE": "EREIGNIS MELDEN", "ANULUJ": "ABBRECHEN", "WYBIERZ KANAŁ": "KANAL AUSWÄHLEN", "ZEZWÓL NA GPS": "GPS ERLAUBEN", "Później": "Später", "Wszystkie": "Alle", "HOME": "STARTSEITE", "CB": "CB", "PROFIL": "PROFIL", "status konta": "Kontostatus"}, "lt": {"EUROPEAN DRIVER NETWORK": "EUROPOS VAIRUOTOJŲ TINKLAS", "GPS + alerty w pobliżu": "GPS + įspėjimai netoliese", "alertów": "įspėjimai", "fotoradarów": "greičio kameros", "kierowców CB": "CB vairuotojai", "Aktywne zgłoszenia": "Aktyvūs pranešimai", "MAPA →": "ŽEMĖLAPIS →", "Powiadom kierowców w pobliżu": "Įspėti netoliese esančius vairuotojus", "TRYB JAZDY AKTYWNY": "VAŽIAVIMO REŽIMAS AKTYVUS", "PRĘDKOŚĆ": "GREITIS", "Brak alertu przed Tobą": "Įspėjimų priešais nėra", "jedno kliknięcie": "vienas paspaudimas", "Wyślij lokalizację kierowcom w pobliżu": "Siųsti vietą netoliese esantiems vairuotojams", "ZAKOŃCZ TRYB JAZDY": "BAIGTI VAŽIAVIMO REŽIMĄ", "WIRTUALNE CB": "VIRTUALUS CB", "KANAŁ": "KANALAS", "KIEROWCY W ZASIĘGU": "VAIRUOTOJAI ZONOJE", "ZASIĘG ODSŁUCHU": "KLAUSYMO SPINDULYS", "PRZYTRZYMAJ, ABY MÓWIĆ": "LAIKYKITE PASPAUDĘ, KAD KALBĖTUMĖTE", "NASŁUCH": "KLAUSYTIS", "MÓJ KIERUNEK": "MANO KRYPTIS", "Ostatnie transmisje": "Paskutinės transliacijos", "Brak transmisji w tej chwili.": "Šiuo metu transliacijų nėra.", "Alerty": "Įspėjimai", "ODŚWIEŻ": "ATNAUJINTI", "Kierowca AURIX": "AURIX vairuotojas", "Profil lokalny": "Vietinis profilis", "przejechane z aktywną AURIX": "nuvažiuota su AURIX", "NIEZALOGOWANY": "NEPRISIJUNGĘS", "ZALOGOWANY": "PRISIJUNGĘS", "GŁOŚNOŚĆ ALERTÓW": "ĮSPĖJIMŲ GARSUMAS", "Dotyczy sygnału i komunikatów głosowych.": "Taikoma signalams ir balso įspėjimams.", "KOMUNIKATY GŁOSOWE": "BALSO ĮSPĖJIMAI", "Lokalizacja": "Vieta", "Nieaktywna": "Neaktyvi", "Powiadomienia": "Pranešimai", "Ustawienia": "Nustatymai", "Mikrofon": "Mikrofonas", "Opcjonalny": "Pasirenkama", "Język aplikacji": "Programėlės kalba", "Prywatność": "Privatumas", "ZDJĘCIE PROFILOWE": "PROFILIO NUOTRAUKA", "NAZWA UŻYTKOWNIKA": "VARTOTOJO VARDAS", "Zmiany profilu zapisują się automatycznie.": "Profilio pakeitimai išsaugomi automatiškai.", "Nie zalogowano": "Neprisijungta", "LOGOWANIE": "PRISIJUNGIMAS", "EMAIL": "EL. PAŠTAS", "HASŁO": "SLAPTAŽODIS", "Zaloguj się": "Prisijungti", "Utwórz konto": "Sukurti paskyrą", "KONTYNUUJ E-MAIL": "TĘSTI EL. PAŠTU", "ZALOGUJ PRZEZ GOOGLE": "PRISIJUNGTI PER GOOGLE", "LUB TELEFON": "ARBA TELEFONU", "KOD WHATSAPP": "WHATSAPP KODAS", "JĘZYK APLIKACJI": "PROGRAMĖLĖS KALBA", "ZGŁOŚ ZDARZENIE": "PRANEŠTI APIE ĮVYKĮ", "ANULUJ": "ATŠAUKTI", "WYBIERZ KANAŁ": "PASIRINKTI KANALĄ", "ZEZWÓL NA GPS": "LEISTI GPS", "Wszystkie": "Visi", "HOME": "PRADŽIA", "CB": "CB", "PROFIL": "PROFIL", "status konta": "PASKYROS BŪSENA"}, "cs": {"EUROPEAN DRIVER NETWORK": "EVROPSKÁ SÍŤ ŘIDIČŮ", "GPS + alerty w pobliżu": "GPS + upozornění v okolí", "alertów": "upozornění", "fotoradarów": "radary", "kierowców CB": "řidiči CB", "Aktywne zgłoszenia": "Aktivní hlášení", "MAPA →": "MAPA →", "Powiadom kierowców w pobliżu": "Upozornit řidiče v okolí", "TRYB JAZDY AKTYWNY": "JÍZDNÍ REŽIM AKTIVNÍ", "PRĘDKOŚĆ": "RYCHLOST", "Brak alertu przed Tobą": "Žádné upozornění před vámi", "jedno kliknięcie": "jedno klepnutí", "Wyślij lokalizację kierowcom w pobliżu": "Odeslat polohu řidičům v okolí", "ZAKOŃCZ TRYB JAZDY": "UKONČIT JÍZDNÍ REŽIM", "WIRTUALNE CB": "VIRTUÁLNÍ CB", "KANAŁ": "KANÁL", "KIEROWCY W ZASIĘGU": "ŘIDIČI V DOSAHU", "ZASIĘG ODSŁUCHU": "DOSAH POSLECHU", "PRZYTRZYMAJ, ABY MÓWIĆ": "PODRŽTE PRO MLUVENÍ", "NASŁUCH": "POSLECH", "MÓJ KIERUNEK": "MŮJ SMĚR", "Ostatnie transmisje": "Poslední přenosy", "Brak transmisji w tej chwili.": "Momentálně žádné přenosy.", "Alerty": "Upozornění", "ODŚWIEŻ": "OBNOVIT", "Kierowca AURIX": "Řidič AURIX", "Profil lokalny": "Místní profil", "przejechane z aktywną AURIX": "ujeto s aktivní aplikací AURIX", "NIEZALOGOWANY": "NEPŘIHLÁŠEN", "ZALOGOWANY": "PŘIHLÁŠEN", "GŁOŚNOŚĆ ALERTÓW": "HLASITOST UPOZORNĚNÍ", "KOMUNIKATY GŁOSOWE": "HLASOVÁ UPOZORNĚNÍ", "Lokalizacja": "Poloha", "Nieaktywna": "Neaktivní", "Powiadomienia": "Oznámení", "Ustawienia": "Nastavení", "Mikrofon": "Mikrofon", "Opcjonalny": "Volitelné", "Prywatność": "Soukromí", "ZDJĘCIE PROFILOWE": "PROFILOVÁ FOTOGRAFIE", "NAZWA UŻYTKOWNIKA": "UŽIVATELSKÉ JMÉNO", "Nie zalogowano": "Nepřihlášeno", "LOGOWANIE": "PŘIHLÁŠENÍ", "EMAIL": "E-MAIL", "HASŁO": "HESLO", "Zaloguj się": "Přihlásit", "Utwórz konto": "Vytvořit účet", "KONTYNUUJ E-MAIL": "POKRAČOVAT E-MAILEM", "ZALOGUJ PRZEZ GOOGLE": "PŘIHLÁSIT PŘES GOOGLE", "LUB TELEFON": "NEBO TELEFONEM", "KOD WHATSAPP": "KÓD WHATSAPP", "JĘZYK APLIKACJI": "JAZYK APLIKACE", "ZGŁOŚ ZDARZENIE": "NAHLÁSIT UDÁLOST", "ANULUJ": "ZRUŠIT", "WYBIERZ KANAŁ": "VYBRAT KANÁL", "ZEZWÓL NA GPS": "POVOLIT GPS", "Wszystkie": "Vše", "HOME": "DOMŮ", "CB": "CB", "PROFIL": "PROFIL", "status konta": "stav účtu"}, "sk": {"EUROPEAN DRIVER NETWORK": "EURÓPSKA SIEŤ VODIČOV", "GPS + alerty w pobliżu": "GPS + upozornenia v okolí", "alertów": "upozornenia", "fotoradarów": "radary", "kierowców CB": "CB vodiči", "Aktywne zgłoszenia": "Aktívne hlásenia", "MAPA →": "MAPA →", "Powiadom kierowców w pobliżu": "Upozorniť vodičov v okolí", "TRYB JAZDY AKTYWNY": "REŽIM JAZDY AKTÍVNY", "PRĘDKOŚĆ": "RÝCHLOSŤ", "Brak alertu przed Tobą": "Žiadne upozornenie pred vami", "jedno kliknięcie": "jedno klepnutie", "Wyślij lokalizację kierowcom w pobliżu": "Odoslať polohu vodičom v okolí", "ZAKOŃCZ TRYB JAZDY": "UKONČIŤ REŽIM JAZDY", "WIRTUALNE CB": "VIRTUÁLNE CB", "KANAŁ": "KANÁL", "KIEROWCY W ZASIĘGU": "VODIČI V DOSAHU", "ZASIĘG ODSŁUCHU": "DOSAH POČÚVANIA", "PRZYTRZYMAJ, ABY MÓWIĆ": "PRE HOVORENIE PODRŽTE", "NASŁUCH": "POČÚVANIE", "MÓJ KIERUNEK": "MÔJ SMER", "Ostatnie transmisje": "Posledné prenosy", "Brak transmisji w tej chwili.": "Momentálne žiadne prenosy.", "Alerty": "Upozornenia", "ODŚWIEŻ": "OBNOVIŤ", "Kierowca AURIX": "Vodič AURIX", "Profil lokalny": "Lokálny profil", "NIEZALOGOWANY": "NEPRIHLÁSENÝ", "ZALOGOWANY": "PRIHLÁSENÝ", "GŁOŚNOŚĆ ALERTÓW": "HLASITOSŤ UPOZORNENÍ", "KOMUNIKATY GŁOSOWE": "HLASOVÉ UPOZORNENIA", "Lokalizacja": "Poloha", "Nieaktywna": "Neaktívna", "Powiadomienia": "Oznámenia", "Ustawienia": "Nastavenia", "Mikrofon": "Mikrofón", "Opcjonalny": "Voliteľné", "Prywatność": "Súkromie", "ZDJĘCIE PROFILOWE": "PROFILOVÁ FOTOGRAFIA", "NAZWA UŻYTKOWNIKA": "POUŽÍVATEĽSKÉ MENO", "Nie zalogowano": "Neprihlásené", "LOGOWANIE": "PRIHLÁSENIE", "EMAIL": "E-MAIL", "HASŁO": "HESLO", "Zaloguj się": "Prihlásiť", "Utwórz konto": "Vytvoriť účet", "KONTYNUUJ E-MAIL": "POKRAČOVAŤ E-MAILOM", "ZALOGUJ PRZEZ GOOGLE": "PRIHLÁSIŤ CEZ GOOGLE", "LUB TELEFON": "ALEBO TELEFÓNOM", "KOD WHATSAPP": "KÓD WHATSAPP", "JĘZYK APLIKACJI": "JAZYK APLIKÁCIE", "ZGŁOŚ ZDARZENIE": "NAHLÁSIŤ UDALOSŤ", "ANULUJ": "ZRUŠIŤ", "WYBIERZ KANAŁ": "VYBRAŤ KANÁL", "ZEZWÓL NA GPS": "POVOLIŤ GPS", "Wszystkie": "Všetky", "HOME": "DOMOV", "CB": "CB", "PROFIL": "PROFIL", "status konta": "stav účtu"}, "uk": {"EUROPEAN DRIVER NETWORK": "ЄВРОПЕЙСЬКА МЕРЕЖА ВОДІЇВ", "GPS + alerty w pobliżu": "GPS + сповіщення поруч", "alertów": "сповіщень", "fotoradarów": "камер швидкості", "kierowców CB": "водіїв CB", "Aktywne zgłoszenia": "Активні повідомлення", "MAPA →": "КАРТА →", "Powiadom kierowców w pobliżu": "Попередити водіїв поруч", "TRYB JAZDY AKTYWNY": "РЕЖИМ ПОЇЗДКИ АКТИВНИЙ", "PRĘDKOŚĆ": "ШВИДКІСТЬ", "Brak alertu przed Tobą": "Попереджень попереду немає", "jedno kliknięcie": "одне натискання", "Wyślij lokalizację kierowcom w pobliżu": "Надіслати місцезнаходження водіям поруч", "ZAKOŃCZ TRYB JAZDY": "ЗАВЕРШИТИ РЕЖИМ ПОЇЗДКИ", "WIRTUALNE CB": "ВІРТУАЛЬНИЙ CB", "KANAŁ": "КАНАЛ", "KIEROWCY W ZASIĘGU": "ВОДІЇ В РАДІУСІ", "ZASIĘG ODSŁUCHU": "РАДІУС ПРОСЛУХОВУВАННЯ", "PRZYTRZYMAJ, ABY MÓWIĆ": "УТРИМУЙТЕ ДЛЯ РОЗМОВИ", "NASŁUCH": "ПРОСЛУХОВУВАННЯ", "MÓJ KIERUNEK": "МІЙ НАПРЯМОК", "Ostatnie transmisje": "Останні передачі", "Brak transmisji w tej chwili.": "Наразі передач немає.", "Alerty": "Сповіщення", "ODŚWIEŻ": "ОНОВИТИ", "Kierowca AURIX": "Водій AURIX", "Profil lokalny": "Локальний профіль", "NIEZALOGOWANY": "НЕ ВИКОНАНО ВХІД", "ZALOGOWANY": "ВИКОНАНО ВХІД", "GŁOŚNOŚĆ ALERTÓW": "ГУЧНІСТЬ СПОВІЩЕНЬ", "KOMUNIKATY GŁOSOWE": "ГОЛОСОВІ СПОВІЩЕННЯ", "Lokalizacja": "Місцезнаходження", "Nieaktywna": "Неактивна", "Powiadomienia": "Сповіщення", "Ustawienia": "Налаштування", "Mikrofon": "Мікрофон", "Opcjonalny": "Необов’язково", "Prywatność": "Конфіденційність", "ZDJĘCIE PROFILOWE": "ФОТО ПРОФІЛЮ", "NAZWA UŻYTKOWNIKA": "ІМ’Я КОРИСТУВАЧА", "Nie zalogowano": "Не виконано вхід", "LOGOWANIE": "ВХІД", "EMAIL": "ЕЛЕКТРОННА ПОШТА", "HASŁO": "ПАРОЛЬ", "Zaloguj się": "Увійти", "Utwórz konto": "Створити обліковий запис", "KONTYNUUJ E-MAIL": "ПРОДОВЖИТИ З E-MAIL", "ZALOGUJ PRZEZ GOOGLE": "УВІЙТИ ЧЕРЕЗ GOOGLE", "LUB TELEFON": "АБО ТЕЛЕФОН", "KOD WHATSAPP": "КОД WHATSAPP", "JĘZYK APLIKACJI": "МОВА ЗАСТОСУНКУ", "ZGŁOŚ ZDARZENIE": "ПОВІДОМИТИ ПРО ПОДІЮ", "ANULUJ": "СКАСУВАТИ", "WYBIERZ KANAŁ": "ВИБРАТИ КАНАЛ", "ZEZWÓL NA GPS": "ДОЗВОЛИТИ GPS", "Wszystkie": "Усі", "HOME": "ГОЛОВНА", "CB": "CB", "PROFIL": "ПРОФІЛЬ", "status konta": "статус облікового запису"}, "ru": {"EUROPEAN DRIVER NETWORK": "ЕВРОПЕЙСКАЯ СЕТЬ ВОДИТЕЛЕЙ", "GPS + alerty w pobliżu": "GPS + предупреждения рядом", "alertów": "предупреждения", "fotoradarów": "камеры скорости", "kierowców CB": "водители CB", "Aktywne zgłoszenia": "Активные сообщения", "MAPA →": "КАРТА →", "Powiadom kierowców w pobliżu": "Предупредить водителей рядом", "TRYB JAZDY AKTYWNY": "РЕЖИМ ПОЕЗДКИ АКТИВЕН", "PRĘDKOŚĆ": "СКОРОСТЬ", "Brak alertu przed Tobą": "Впереди нет предупреждений", "jedno kliknięcie": "одно нажатие", "Wyślij lokalizację kierowcom w pobliżu": "Отправить местоположение водителям рядом", "ZAKOŃCZ TRYB JAZDY": "ЗАВЕРШИТЬ РЕЖИМ ПОЕЗДКИ", "WIRTUALNE CB": "ВИРТУАЛЬНЫЙ CB", "KANAŁ": "КАНАЛ", "KIEROWCY W ZASIĘGU": "ВОДИТЕЛИ В РАДИУСЕ", "ZASIĘG ODSŁUCHU": "РАДИУС ПРОСЛУШИВАНИЯ", "PRZYTRZYMAJ, ABY MÓWIĆ": "УДЕРЖИВАЙТЕ ДЛЯ РЕЧИ", "NASŁUCH": "ПРОСЛУШИВАНИЕ", "MÓJ KIERUNEK": "МОЁ НАПРАВЛЕНИЕ", "Ostatnie transmisje": "Последние передачи", "Brak transmisji w tej chwili.": "Сейчас передач нет.", "Alerty": "ОПОВЕЩЕНИЯ", "ODŚWIEŻ": "ОБНОВИТЬ", "Kierowca AURIX": "Водитель AURIX", "Profil lokalny": "Локальный профиль", "NIEZALOGOWANY": "НЕ ВЫПОЛНЕН ВХОД", "ZALOGOWANY": "ВХОД ВЫПОЛНЕН", "GŁOŚNOŚĆ ALERTÓW": "ГРОМКОСТЬ ОПОВЕЩЕНИЙ", "KOMUNIKATY GŁOSOWE": "ГОЛОСОВЫЕ ОПОВЕЩЕНИЯ", "Lokalizacja": "Местоположение", "Nieaktywna": "Неактивна", "Powiadomienia": "Уведомления", "Ustawienia": "Настройки", "Mikrofon": "Микрофон", "Opcjonalny": "Необязательно", "Prywatność": "Конфиденциальность", "ZDJĘCIE PROFILOWE": "ФОТО ПРОФИЛЯ", "NAZWA UŻYTKOWNIKA": "ИМЯ ПОЛЬЗОВАТЕЛЯ", "Nie zalogowano": "Не выполнен вход", "LOGOWANIE": "ВХОД", "EMAIL": "ЭЛЕКТРОННАЯ ПОЧТА", "HASŁO": "ПАРОЛЬ", "Zaloguj się": "Войти", "Utwórz konto": "Создать аккаунт", "KONTYNUUJ E-MAIL": "ПРОДОЛЖИТЬ С E-MAIL", "ZALOGUJ PRZEZ GOOGLE": "ВОЙТИ ЧЕРЕЗ GOOGLE", "LUB TELEFON": "ИЛИ ТЕЛЕФОН", "KOD WHATSAPP": "КОД WHATSAPP", "JĘZYK APLIKACJI": "ЯЗЫК ПРИЛОЖЕНИЯ", "ZGŁOŚ ZDARZENIE": "СООБЩИТЬ О СОБЫТИИ", "ANULUJ": "ОТМЕНА", "WYBIERZ KANAŁ": "ВЫБРАТЬ КАНАЛ", "ZEZWÓL NA GPS": "РАЗРЕШИТЬ GPS", "Wszystkie": "Все", "HOME": "ГЛАВНАЯ", "CB": "CB", "PROFIL": "ПРОФИЛЬ", "status konta": "статус аккаунта"}, "it": {"EUROPEAN DRIVER NETWORK": "RETE EUROPEA DEI CONDUCENTI", "GPS + alerty w pobliżu": "GPS + avvisi nelle vicinanze", "alertów": "avvisi", "fotoradarów": "autovelox", "kierowców CB": "conducenti CB", "Aktywne zgłoszenia": "Segnalazioni attive", "MAPA →": "MAPPA →", "Powiadom kierowców w pobliżu": "Avvisa i conducenti vicini", "TRYB JAZDY AKTYWNY": "MODALITÀ GUIDA ATTIVA", "PRĘDKOŚĆ": "VELOCITÀ", "Brak alertu przed Tobą": "Nessun avviso davanti", "jedno kliknięcie": "un tocco", "Wyślij lokalizację kierowcom w pobliżu": "Invia posizione ai conducenti vicini", "ZAKOŃCZ TRYB JAZDY": "TERMINA MODALITÀ GUIDA", "WIRTUALNE CB": "CB VIRTUALE", "KANAŁ": "CANALE", "KIEROWCY W ZASIĘGU": "CONDUCENTI NEL RAGGIO", "ZASIĘG ODSŁUCHU": "RAGGIO DI ASCOLTO", "PRZYTRZYMAJ, ABY MÓWIĆ": "TIENI PREMUTO PER PARLARE", "NASŁUCH": "ASCOLTO", "MÓJ KIERUNEK": "LA MIA DIREZIONE", "Ostatnie transmisje": "Ultime trasmissioni", "Brak transmisji w tej chwili.": "Nessuna trasmissione al momento.", "Alerty": "Avvisi", "ODŚWIEŻ": "AGGIORNA", "Kierowca AURIX": "Conducente AURIX", "Profil lokalny": "Profilo locale", "NIEZALOGOWANY": "NON CONNESSO", "ZALOGOWANY": "CONNESSO", "GŁOŚNOŚĆ ALERTÓW": "VOLUME AVVISI", "KOMUNIKATY GŁOSOWE": "AVVISI VOCALI", "Lokalizacja": "Posizione", "Nieaktywna": "Inattiva", "Powiadomienia": "Notifiche", "Ustawienia": "Impostazioni", "Mikrofon": "Microfono", "Opcjonalny": "Opzionale", "Prywatność": "Privacy", "ZDJĘCIE PROFILOWE": "FOTO PROFILO", "NAZWA UŻYTKOWNIKA": "NOME UTENTE", "Nie zalogowano": "Non connesso", "LOGOWANIE": "ACCESSO", "EMAIL": "E-MAIL", "HASŁO": "PASSWORD", "Zaloguj się": "Accedi", "Utwórz konto": "Crea account", "KONTYNUUJ E-MAIL": "CONTINUA CON E-MAIL", "ZALOGUJ PRZEZ GOOGLE": "ACCEDI CON GOOGLE", "LUB TELEFON": "O TELEFONO", "KOD WHATSAPP": "CODICE WHATSAPP", "JĘZYK APLIKACJI": "LINGUA APP", "ZGŁOŚ ZDARZENIE": "SEGNALA EVENTO", "ANULUJ": "ANNULLA", "WYBIERZ KANAŁ": "SCEGLI CANALE", "ZEZWÓL NA GPS": "CONSENTI GPS", "Wszystkie": "Tutti", "HOME": "HOME", "CB": "CB", "PROFIL": "PROFILO", "status konta": "stato account"}, "es": {"EUROPEAN DRIVER NETWORK": "RED EUROPEA DE CONDUCTORES", "GPS + alerty w pobliżu": "GPS + alertas cercanas", "alertów": "alertas", "fotoradarów": "radares", "kierowców CB": "conductores CB", "Aktywne zgłoszenia": "Avisos activos", "MAPA →": "MAPA →", "Powiadom kierowców w pobliżu": "Avisar a conductores cercanos", "TRYB JAZDY AKTYWNY": "MODO CONDUCCIÓN ACTIVO", "PRĘDKOŚĆ": "VELOCIDAD", "Brak alertu przed Tobą": "No hay alerta delante", "jedno kliknięcie": "un toque", "Wyślij lokalizację kierowcom w pobliżu": "Enviar ubicación a conductores cercanos", "ZAKOŃCZ TRYB JAZDY": "FINALIZAR MODO CONDUCCIÓN", "WIRTUALNE CB": "CB VIRTUAL", "KANAŁ": "CANAL", "KIEROWCY W ZASIĘGU": "CONDUCTORES EN RANGO", "ZASIĘG ODSŁUCHU": "RADIO DE ESCUCHA", "PRZYTRZYMAJ, ABY MÓWIĆ": "MANTÉN PULSADO PARA HABLAR", "NASŁUCH": "ESCUCHAR", "MÓJ KIERUNEK": "MI DIRECCIÓN", "Ostatnie transmisje": "Últimas transmisiones", "Brak transmisji w tej chwili.": "No hay transmisiones ahora.", "Alerty": "Alertas", "ODŚWIEŻ": "ACTUALIZAR", "Kierowca AURIX": "Conductor AURIX", "Profil lokalny": "Perfil local", "NIEZALOGOWANY": "NO CONECTADO", "ZALOGOWANY": "CONECTADO", "GŁOŚNOŚĆ ALERTÓW": "VOLUMEN DE ALERTAS", "KOMUNIKATY GŁOSOWE": "ALERTAS DE VOZ", "Lokalizacja": "Ubicación", "Nieaktywna": "Inactiva", "Powiadomienia": "Notificaciones", "Ustawienia": "Ajustes", "Mikrofon": "Micrófono", "Opcjonalny": "Opcional", "Prywatność": "Privacidad", "ZDJĘCIE PROFILOWE": "FOTO DE PERFIL", "NAZWA UŻYTKOWNIKA": "NOMBRE DE USUARIO", "Nie zalogowano": "No conectado", "LOGOWANIE": "INICIO DE SESIÓN", "EMAIL": "EMAIL", "HASŁO": "CONTRASEÑA", "Zaloguj się": "Iniciar sesión", "Utwórz konto": "Crear cuenta", "KONTYNUUJ E-MAIL": "CONTINUAR CON EMAIL", "ZALOGUJ PRZEZ GOOGLE": "INICIAR CON GOOGLE", "LUB TELEFON": "O TELÉFONO", "KOD WHATSAPP": "CÓDIGO WHATSAPP", "JĘZYK APLIKACJI": "IDIOMA DE LA APP", "ZGŁOŚ ZDARZENIE": "REPORTAR EVENTO", "ANULUJ": "CANCELAR", "WYBIERZ KANAŁ": "ELEGIR CANAL", "ZEZWÓL NA GPS": "PERMITIR GPS", "Wszystkie": "Todos", "HOME": "INICIO", "CB": "CB", "PROFIL": "PERFIL", "status konta": "estado de la cuenta"}};
Object.entries(I18N_UI_EXTRA).forEach(([lang,dict])=>Object.assign(I18N[lang]||{},dict));



const NEW_SETTINGS_I18N={
'Głos i dźwięki':{pl:'Głos i dźwięki',en:'Voice & sounds',nl:'Stem en geluid',de:'Stimme & Töne',lt:'Balsas ir garsai',cs:'Hlas a zvuky',sk:'Hlas a zvuky',uk:'Голос і звуки',ru:'Голос и звуки',it:'Voce e suoni',es:'Voz y sonidos'},
'Zgłoszenia':{pl:'Zgłoszenia',en:'Reports',nl:'Meldingen',de:'Meldungen',lt:'Pranešimai',cs:'Hlášení',sk:'Hlásenia',uk:'Повідомлення',ru:'Сообщения',it:'Segnalazioni',es:'Avisos'},
'Odległość do zagrożenia':{pl:'Odległość do zagrożenia',en:'Hazard distance',nl:'Afstand tot gevaar',de:'Gefahrenentfernung',lt:'Atstumas iki pavojaus',cs:'Vzdálenost k nebezpečí',sk:'Vzdialenosť k nebezpečenstvu',uk:'Відстань до небезпеки',ru:'Расстояние до опасности',it:'Distanza dal pericolo',es:'Distancia al peligro'},
'USTAWIENIA DLA ZALOGOWANEGO':{pl:'USTAWIENIA DLA ZALOGOWANEGO',en:'SIGNED-IN SETTINGS',nl:'INSTELLINGEN VOOR INGLOGDE GEBRUIKER',de:'EINSTELLUNGEN FÜR ANGEMELDETE NUTZER',lt:'PRISIJUNGUSIO VARTOTOJO NUSTATYMAI',cs:'NASTAVENÍ PŘIHLÁŠENÉHO UŽIVATELE',sk:'NASTAVENIA PRIHLÁSENÉHO POUŽÍVATEĽA',uk:'НАЛАШТУВАННЯ ДЛЯ КОРИСТУВАЧА',ru:'НАСТРОЙКИ АВТОРИЗОВАННОГО ПОЛЬЗОВАТЕЛЯ',it:'IMPOSTAZIONI UTENTE',es:'AJUSTES DEL USUARIO'},
'Pokaż na mapie':{pl:'Pokaż na mapie',en:'Show on map',nl:'Op kaart tonen',de:'Auf Karte anzeigen',lt:'Rodyti žemėlapyje',cs:'Zobrazit na mapě',sk:'Zobraziť na mape',uk:'Показувати на карті',ru:'Показывать на карте',it:'Mostra sulla mappa',es:'Mostrar en el mapa'},
'Ostrzegaj podczas jazdy':{pl:'Ostrzegaj podczas jazdy',en:'Alert while driving',nl:'Waarschuw tijdens het rijden',de:'Während der Fahrt warnen',lt:'Įspėti vairuojant',cs:'Upozorňovat při jízdě',sk:'Upozorňovať počas jazdy',uk:'Попереджати під час руху',ru:'Предупреждать во время поездки',it:'Avvisa durante la guida',es:'Avisar durante la conducción'},
'Pokaż na mapie i ostrzegaj podczas jazdy':{pl:'Pokaż na mapie i ostrzegaj podczas jazdy',en:'Show on map and alert while driving',nl:'Op kaart tonen en waarschuwen tijdens het rijden',de:'Auf Karte anzeigen und während der Fahrt warnen',lt:'Rodyti žemėlapyje ir įspėti vairuojant',cs:'Zobrazit na mapě a upozorňovat při jízdě',sk:'Zobraziť na mape a upozorňovať počas jazdy',uk:'Показувати на карті та попереджати під час руху',ru:'Показывать на карте и предупреждать во время поездки',it:'Mostra sulla mappa e avvisa durante la guida',es:'Mostrar en el mapa y avisar al conducir'},
'Standardowe':{pl:'Standardowe',en:'Standard',nl:'Standaard',de:'Standard',lt:'Standartinis',cs:'Standardní',sk:'Štandardné',uk:'Стандартні',ru:'Стандартные',it:'Standard',es:'Estándar'},
'Ograniczone':{pl:'Ograniczone',en:'Limited',nl:'Beperkt',de:'Eingeschränkt',lt:'Ribotas',cs:'Omezené',sk:'Obmedzené',uk:'Обмежені',ru:'Ограниченные',it:'Limitato',es:'Limitado'},
'Tylko ostrzeżenia':{pl:'Tylko ostrzeżenia',en:'Warnings only',nl:'Alleen waarschuwingen',de:'Nur Warnungen',lt:'Tik įspėjimai',cs:'Pouze upozornění',sk:'Len upozornenia',uk:'Лише попередження',ru:'Только предупреждения',it:'Solo avvisi',es:'Solo avisos'},
'Wyłącz':{pl:'Wyłącz',en:'Off',nl:'Uit',de:'Aus',lt:'Išjungta',cs:'Vypnuto',sk:'Vypnuté',uk:'Вимкнено',ru:'Выключено',it:'Disattivato',es:'Desactivado'},
'Pełne sygnały i komunikaty głosowe.':{pl:'Pełne sygnały i komunikaty głosowe.',en:'Full sounds and voice alerts.',nl:'Volledige geluiden en stemwaarschuwingen.',de:'Volle Töne und Sprachwarnungen.',lt:'Visi garsai ir balso įspėjimai.',cs:'Plné zvuky a hlasová upozornění.',sk:'Plné zvuky a hlasové upozornenia.',uk:'Повні звуки та голосові попередження.',ru:'Полные звуки и голосовые предупреждения.',it:'Suoni e avvisi vocali completi.',es:'Sonidos y avisos de voz completos.'},
'Komunikaty głosowe tylko bliżej zagrożenia.':{pl:'Komunikaty głosowe tylko bliżej zagrożenia.',en:'Voice alerts only closer to the hazard.',nl:'Stemwaarschuwingen alleen dichter bij het gevaar.',de:'Sprachwarnungen erst näher am Gefahrpunkt.',lt:'Balso įspėjimai tik arčiau pavojaus.',cs:'Hlasová upozornění pouze blíže k nebezpečí.',sk:'Hlasové upozornenia iba bližšie k nebezpečenstvu.',uk:'Голосові попередження лише ближче до небезпеки.',ru:'Голосовые предупреждения только ближе к опасности.',it:'Avvisi vocali solo più vicino al pericolo.',es:'Avisos de voz solo cerca del peligro.'},
'Tylko alerty o wyższym priorytecie.':{pl:'Tylko alerty o wyższym priorytecie.',en:'Only higher-priority alerts.',nl:'Alleen waarschuwingen met hogere prioriteit.',de:'Nur Warnungen mit höherer Priorität.',lt:'Tik aukštesnio prioriteto įspėjimai.',cs:'Pouze upozornění s vyšší prioritou.',sk:'Len upozornenia s vyššou prioritou.',uk:'Лише попередження високого пріоритету.',ru:'Только предупреждения высокого приоритета.',it:'Solo avvisi ad alta priorità.',es:'Solo avisos de mayor prioridad.'},
'Bez dźwięków i komunikatów głosowych.':{pl:'Bez dźwięków i komunikatów głosowych.',en:'No sounds or voice alerts.',nl:'Geen geluiden of stemwaarschuwingen.',de:'Keine Töne oder Sprachwarnungen.',lt:'Be garsų ir balso įspėjimų.',cs:'Bez zvuků a hlasových upozornění.',sk:'Bez zvukov a hlasových upozornení.',uk:'Без звуків і голосових попереджень.',ru:'Без звуков и голосовых предупреждений.',it:'Nessun suono o avviso vocale.',es:'Sin sonidos ni avisos de voz.'},
'Aktualny głos':{pl:'Aktualny głos',en:'Current voice',nl:'Huidige stem',de:'Aktuelle Stimme',lt:'Dabartinis balsas',cs:'Aktuální hlas',sk:'Aktuálny hlas',uk:'Поточний голос',ru:'Текущий голос',it:'Voce attuale',es:'Voz actual'},
'Głos urządzenia':{pl:'Głos urządzenia',en:'Device voice',nl:'Apparaatstem',de:'Gerätestimme',lt:'Įrenginio balsas',cs:'Hlas zařízení',sk:'Hlas zariadenia',uk:'Голос пристрою',ru:'Голос устройства',it:'Voce del dispositivo',es:'Voz del dispositivo'},
'Głośność':{pl:'Głośność',en:'Volume',nl:'Volume',de:'Lautstärke',lt:'Garsumas',cs:'Hlasitost',sk:'Hlasitosť',uk:'Гучність',ru:'Громкость',it:'Volume',es:'Volumen'},
'Komunikaty głosowe':{pl:'Komunikaty głosowe',en:'Voice alerts',nl:'Stemwaarschuwingen',de:'Sprachwarnungen',lt:'Balso įspėjimai',cs:'Hlasová upozornění',sk:'Hlasové upozornenia',uk:'Голосові попередження',ru:'Голосовые предупреждения',it:'Avvisi vocali',es:'Avisos de voz'},
'Zależne od języka aplikacji.':{pl:'Zależne od języka aplikacji.',en:'Follows the app language.',nl:'Volgt de taal van de app.',de:'Folgt der App-Sprache.',lt:'Priklauso nuo programėlės kalbos.',cs:'Řídí se jazykem aplikace.',sk:'Závisí od jazyka aplikácie.',uk:'Залежить від мови застосунку.',ru:'Зависит от языка приложения.',it:'Segue la lingua dell’app.',es:'Sigue el idioma de la app.'},
'Dźwięk alertów':{pl:'Dźwięk alertów',en:'Alert sounds',nl:'Geluiden van waarschuwingen',de:'Warntöne',lt:'Įspėjimų garsas',cs:'Zvuky upozornění',sk:'Zvuky upozornení',uk:'Звуки попереджень',ru:'Звуки предупреждений',it:'Suoni degli avvisi',es:'Sonidos de avisos'},
'Sygnał przed komunikatem.':{pl:'Sygnał przed komunikatem.',en:'Sound before the voice message.',nl:'Geluid vóór de stemmelding.',de:'Signal vor der Sprachausgabe.',lt:'Signalas prieš balso pranešimą.',cs:'Signál před hlasovou zprávou.',sk:'Signál pred hlasovou správou.',uk:'Сигнал перед голосовим повідомленням.',ru:'Сигнал перед голосовым сообщением.',it:'Segnale prima del messaggio vocale.',es:'Señal antes del mensaje de voz.'},
'Zaloguj się, aby zmieniać ustawienia':{pl:'Zaloguj się, aby zmieniać ustawienia',en:'Sign in to change settings',nl:'Log in om instellingen te wijzigen',de:'Anmelden, um Einstellungen zu ändern',lt:'Prisijunkite, kad keistumėte nustatymus',cs:'Přihlaste se pro změnu nastavení',sk:'Prihláste sa pre zmenu nastavení',uk:'Увійдіть, щоб змінювати налаштування',ru:'Войдите, чтобы изменить настройки',it:'Accedi per modificare le impostazioni',es:'Inicia sesión para cambiar los ajustes'},
'Tylko na drodze':{pl:'Tylko na drodze',en:'On road only',nl:'Alleen op de weg',de:'Nur auf der Straße',lt:'Tik kelyje',cs:'Pouze na silnici',sk:'Len na ceste',uk:'Лише на дорозі',ru:'Только на дороге',it:'Solo sulla strada',es:'Solo en carretera'}
};
const I18N_COMMON={
'100 m':{pl:'100 m',en:'100 m',nl:'100 m',de:'100 m',lt:'100 m',cs:'100 m',sk:'100 m',uk:'100 м',ru:'100 м',it:'100 m',es:'100 m'},
'300 m':{pl:'300 m',en:'300 m',nl:'300 m',de:'300 m',lt:'300 m',cs:'300 m',sk:'300 m',uk:'300 м',ru:'300 м',it:'300 m',es:'300 m'},
'500 m':{pl:'500 m',en:'500 m',nl:'500 m',de:'500 m',lt:'500 m',cs:'500 m',sk:'500 m',uk:'500 м',ru:'500 м',it:'500 m',es:'500 m'},
'1 km':{pl:'1 km',en:'1 km',nl:'1 km',de:'1 km',lt:'1 km',cs:'1 km',sk:'1 km',uk:'1 км',ru:'1 км',it:'1 km',es:'1 km'},
'2 km':{pl:'2 km',en:'2 km',nl:'2 km',de:'2 km',lt:'2 km',cs:'2 km',sk:'2 km',uk:'2 км',ru:'2 км',it:'2 km',es:'2 km'},
'5 km':{pl:'5 km',en:'5 km',nl:'5 km',de:'5 km',lt:'5 km',cs:'5 km',sk:'5 km',uk:'5 км',ru:'5 км',it:'5 km',es:'5 km'},
'Odległość alertów':{pl:'Odległość alertów',en:'Alert distance',nl:'Afstand waarschuwingen',de:'Warnentfernung',lt:'Įspėjimo atstumas',cs:'Vzdálenost upozornění',sk:'Vzdialenosť upozornenia',uk:'Відстань попередження',ru:'Расстояние предупреждения',it:'Distanza avviso',es:'Distancia de alerta'},
'GPS: ON':{pl:'GPS: WŁ.',en:'GPS: ON',nl:'GPS: AAN',de:'GPS: AN',lt:'GPS: ĮJ.',cs:'GPS: ZAP.',sk:'GPS: ZAP.',uk:'GPS: УВІМК.',ru:'GPS: ВКЛ.',it:'GPS: ON',es:'GPS: ON'},
'Aktywna':{pl:'Aktywna',en:'Active',nl:'Actief',de:'Aktiv',lt:'Aktyvi',cs:'Aktivní',sk:'Aktívna',uk:'Активна',ru:'Активна',it:'Attiva',es:'Activa'},
'w pobliżu':{pl:'w pobliżu',en:'nearby',nl:'in de buurt',de:'in der Nähe',lt:'netoliese',cs:'v okolí',sk:'v okolí',uk:'поруч',ru:'рядом',it:'nelle vicinanze',es:'cerca'},
'aktywne':{pl:'aktywne',en:'active',nl:'actief',de:'aktiv',lt:'aktyvūs',cs:'aktivní',sk:'aktívne',uk:'активні',ru:'активных',it:'attivi',es:'activas'},
'Tryb jazdy aktywny':{pl:'Tryb jazdy aktywny',en:'Drive mode active',nl:'Ritmodus actief',de:'Fahrmodus aktiv',lt:'Važiavimo režimas aktyvus',cs:'Jízdní režim aktivní',sk:'Režim jazdy aktívny',uk:'Режим поїздки активний',ru:'Режим поездки активен',it:'Modalità guida attiva',es:'Modo conducción activo'},
'GPS: OFF':{pl:'GPS: WYŁ.',en:'GPS: OFF',nl:'GPS: UIT',de:'GPS: AUS',lt:'GPS: IŠJ.',cs:'GPS: VYP.',sk:'GPS: VYP.',uk:'GPS: ВИМК.',ru:'GPS: ВЫКЛ.',it:'GPS: OFF',es:'GPS: OFF'},
'CB Radio':{pl:'CB Radio',en:'CB Radio',nl:'CB-radio',de:'CB-Funk',lt:'CB radijas',cs:'CB rádio',sk:'CB rádio',uk:'CB-радіо',ru:'CB-радио',it:'Radio CB',es:'Radio CB'},
'km/h':{pl:'km/h',en:'km/h',nl:'km/u',de:'km/h',lt:'km/h',cs:'km/h',sk:'km/h',uk:'км/год',ru:'км/ч',it:'km/h',es:'km/h'},
'KANAŁ 19':{pl:'KANAŁ 19',en:'CHANNEL 19',nl:'KANAAL 19',de:'KANAL 19',lt:'KANALAS 19',cs:'KANÁL 19',sk:'KANÁL 19',uk:'КАНАЛ 19',ru:'КАНАЛ 19',it:'CANALE 19',es:'CANAL 19'},
'PHONE_PLACEHOLDER':{pl:'+48 123 456 789',en:'+44 7123 456789',nl:'+31 6 12345678',de:'+49 151 12345678',lt:'+370 612 34567',cs:'+420 123 456 789',sk:'+421 912 345 678',uk:'+380 67 123 4567',ru:'+7 900 123-45-67',it:'+39 333 1234567',es:'+34 612 345 678'},
'Wpisz kod':{pl:'Wpisz kod',en:'Enter code',nl:'Voer code in',de:'Code eingeben',lt:'Įveskite kodą',cs:'Zadejte kód',sk:'Zadajte kód',uk:'Введіть код',ru:'Введите код',it:'Inserisci codice',es:'Introduce el código'},
'Zbliżasz się do zgłoszenia.':{pl:'Zbliżasz się do zgłoszenia.',en:'You are approaching a report.',nl:'Je nadert een melding.',de:'Du näherst dich einer Meldung.',lt:'Artėjate prie pranešimo.',cs:'Blížíte se k hlášení.',sk:'Blížite sa k hláseniu.',uk:'Ви наближаєтеся до повідомлення.',ru:'Вы приближаетесь к сообщению.',it:'Ti stai avvicinando a una segnalazione.',es:'Te acercas a un aviso.'},
'od Ciebie':{pl:'od Ciebie',en:'from you',nl:'van jou',de:'von dir',lt:'nuo jūsų',cs:'od vás',sk:'od vás',uk:'від вас',ru:'от вас',it:'da te',es:'de ti'},
'Pobieram lokalizację…':{pl:'Pobieram lokalizację…',en:'Getting location…',nl:'Locatie ophalen…',de:'Standort wird abgerufen…',lt:'Gaunama vieta…',cs:'Načítám polohu…',sk:'Načítavam polohu…',uk:'Отримую місцезнаходження…',ru:'Получаю местоположение…',it:'Recupero posizione…',es:'Obteniendo ubicación…'},
'JAZDA AKTYWNA':{pl:'JAZDA AKTYWNA',en:'DRIVE ACTIVE',nl:'RIT ACTIEF',de:'FAHRMODUS AKTIV',lt:'VAŽIAVIMAS AKTYVUS',cs:'JÍZDA AKTIVNÍ',sk:'JAZDA AKTÍVNA',uk:'ПОЇЗДКА АКТИВНА',ru:'ПОЕЗДКА АКТИВНА',it:'GUIDA ATTIVA',es:'CONDUCCIÓN ACTIVA'},
'Alerty są aktywne':{pl:'Alerty są aktywne',en:'Alerts are active',nl:'Waarschuwingen zijn actief',de:'Warnungen sind aktiv',lt:'Įspėjimai aktyvūs',cs:'Upozornění jsou aktivní',sk:'Upozornenia sú aktívne',uk:'Сповіщення активні',ru:'Оповещения активны',it:'Gli avvisi sono attivi',es:'Las alertas están activas'},
'Tryb jazdy aktywny':{pl:'Tryb jazdy aktywny',en:'Drive mode active',nl:'Ritmodus actief',de:'Fahrmodus aktiv',lt:'Važiavimo režimas aktyvus',cs:'Jízdní režim aktivní',sk:'Režim jazdy aktívny',uk:'Режим поїздки активний',ru:'Режим поездки активен',it:'Modalità guida attiva',es:'Modo conducción activo'},
'zapisano pozycję GPS':{pl:'zapisano pozycję GPS',en:'GPS position saved',nl:'GPS-locatie opgeslagen',de:'GPS-Position gespeichert',lt:'GPS vieta išsaugota',cs:'GPS poloha uložena',sk:'GPS poloha uložená',uk:'GPS-позицію збережено',ru:'GPS-позиция сохранена',it:'posizione GPS salvata',es:'posición GPS guardada'},
'Zgłoszenie potwierdzone':{pl:'Zgłoszenie potwierdzone',en:'Report confirmed',nl:'Melding bevestigd',de:'Meldung bestätigt',lt:'Pranešimas patvirtintas',cs:'Hlášení potvrzeno',sk:'Hlásenie potvrdené',uk:'Повідомлення підтверджено',ru:'Сообщение подтверждено',it:'Segnalazione confermata',es:'Aviso confirmado'},
'Zgłoszenie odwołane':{pl:'Zgłoszenie odwołane',en:'Report dismissed',nl:'Melding afgewezen',de:'Meldung verworfen',lt:'Pranešimas atmestas',cs:'Hlášení zamítnuto',sk:'Hlásenie zamietnuté',uk:'Повідомлення скасовано',ru:'Сообщение отменено',it:'Segnalazione respinta',es:'Aviso descartado'},
'potwierdzeń':{pl:'potwierdzeń',en:'confirmations',nl:'bevestigingen',de:'Bestätigungen',lt:'patvirtinimų',cs:'potvrzení',sk:'potvrdení',uk:'підтверджень',ru:'подтверждений',it:'conferme',es:'confirmaciones'}
};
Object.entries(NEW_SETTINGS_I18N).forEach(([key,langs])=>Object.entries(langs).forEach(([lang,val])=>{if(I18N[lang])I18N[lang][key]=val;}));
Object.entries(I18N_COMMON).forEach(([key,langs])=>Object.entries(langs).forEach(([lang,val])=>{if(I18N[lang])I18N[lang][key]=val;}));
const DEFAULT_ACCOUNT_SETTINGS={
 soundMode:'standard',voiceEnabled:true,alertSoundEnabled:true,alertVolume:.75,voiceName:'',alertDistance:'5km',language:'pl',
 mapReports:{accident:true,police:true,camera:true,roadworks:true,traffic:true,vehicle:true,road:true,animal:true,weather:true,other:true},
 driveAlerts:{accident:true,police:true,camera:true,roadworks:true,traffic:true,vehicle:true,road:true,animal:true,weather:true,other:true}
};
const state={reports:[],cameras:[],helpRequests:[],driveKm:0,driveLastPos:null,userPos:null,heading:null,speed:0,map:null,userMarker:null,reportLayer:null,cameraLayer:null,selectedFilter:'all',driving:false,range:10,recording:false,mediaRecorder:null,watchId:null,channel:19,listen:true,directionOnly:false,passed:new Set(),alertStates:new Map(),alertDistanceHistory:new Map(),dismissedAlerts:new Set(),currentAlert:null,cbDrivers:0,cbOnline:false,votes:{},alertVolume:.75,voiceAlerts:true,alertSoundEnabled:true,onlineUsers:0,onlineChannel:null,onlinePresenceReady:false,cbSocket:null,cbPeers:new Map(),cbStream:null,cbAudioEls:new Map(),soundMode:'standard',voiceName:'',alertDistance:'5km',audioContext:null,language:'pl',localSettings:{...DEFAULT_ACCOUNT_SETTINGS},nativeBackgroundGps:false,nativeNotifications:false,nativeKeepScreenOn:false,nativeAudio:true,nativeHaptics:true,nativeAutoStart:false,nativeAndroidAuto:true};
const ALERT_DISTANCE_OPTIONS=[['100m',0.1,'100 m'],['300m',0.3,'300 m'],['500m',0.5,'500 m'],['1km',1,'1 km'],['2km',2,'2 km'],['5km',5,'5 km']];
const ALERT_DISTANCE_MAP=Object.fromEntries(ALERT_DISTANCE_OPTIONS.map(([id,km])=>[id,km]));
function normalizeAlertDistance(value){
 const v=String(value||'5km');
 if(ALERT_DISTANCE_MAP[v])return v;
 // Migracja starych ustawień AURIX do nowego modelu.
 if(v==='100'||v==='200')return '5km';
 if(v==='50'||v==='25'||v==='all'||v==='road')return '5km';
 if(v==='5')return '5km';
 return '5km';
}
function alertDistanceKm(){return ALERT_DISTANCE_MAP[normalizeAlertDistance(state.alertDistance)]||5;}
function alertDistanceMeters(){return alertDistanceKm()*1000;}
function alertThresholdsMeters(){
 const max=alertDistanceMeters();
 const base=[5000,2000,1000,500,300,100];
 return [...new Set([max,...base.filter(v=>v<max)])].sort((a,b)=>b-a);
}

function accountSettings(){const a=state.localSettings||{};return {...DEFAULT_ACCOUNT_SETTINGS,...a,mapReports:{...DEFAULT_ACCOUNT_SETTINGS.mapReports,...(a.mapReports||{})},driveAlerts:{...DEFAULT_ACCOUNT_SETTINGS.driveAlerts,...(a.driveAlerts||{})}}}
function applyAccountSettings(s){const x={...DEFAULT_ACCOUNT_SETTINGS,...(s||{})};state.alertVolume=Math.min(1,Math.max(.1,Number(x.alertVolume)||.75));state.voiceAlerts=x.voiceEnabled!==false;state.alertSoundEnabled=x.alertSoundEnabled!==false;state.soundMode=x.soundMode||'standard';state.voiceName=x.voiceName||'';state.alertDistance=normalizeAlertDistance(x.alertDistance);if(x.language&&LANGUAGES[x.language])state.language=x.language}

function t(key){return I18N[state.language]?.[key]||I18N.en?.[key]||I18N.pl?.[key]||key}
function applyTranslations(){document.documentElement.lang=state.language;$$('[data-i18n]').forEach(el=>{const k=el.dataset.i18n;if(el.dataset.i18nAttr){el.setAttribute(el.dataset.i18nAttr,t(k));}else{const tag=el.tagName;if(tag==='OPTION')el.textContent=t(k);else if(tag==='INPUT'||tag==='TEXTAREA')el.placeholder=t(k);else el.textContent=t(k)}});$$('[data-i18n-placeholder]').forEach(el=>el.placeholder=t(el.dataset.i18nPlaceholder));renderLanguages();renderReportButtons();renderFilters();renderCbTitle();renderSettingsSummary();updateNativeSettingsUI();}
function localizedReportLabel(type){const labels={pl:{accident:'Wypadek',police:'Policja / kontrola',camera:'Fotoradar',roadworks:'Roboty drogowe',traffic:'Korek',vehicle:'Pojazd / awaria',road:'Uszkodzona droga',animal:'Zwierzę na drodze',weather:'Warunki pogodowe',other:'Inne zagrożenie'},en:{accident:'Accident',police:'Police / control',camera:'Speed camera',roadworks:'Roadworks',traffic:'Traffic jam',vehicle:'Vehicle / breakdown',road:'Damaged road',animal:'Animal on road',weather:'Weather conditions',other:'Other hazard'},nl:{accident:'Ongeval',police:'Politie / controle',camera:'Flitspaal',roadworks:'Wegwerkzaamheden',traffic:'File',vehicle:'Voertuig / pech',road:'Beschadigde weg',animal:'Dier op de weg',weather:'Weersomstandigheden',other:'Ander gevaar'},de:{accident:'Unfall',police:'Polizei / Kontrolle',camera:'Blitzer',roadworks:'Baustelle',traffic:'Stau',vehicle:'Fahrzeug / Panne',road:'Beschädigte Straße',animal:'Tier auf der Straße',weather:'Wetterbedingungen',other:'Andere Gefahr'},lt:{accident:'Avarija',police:'Policija / kontrolė',camera:'Greičio kamera',roadworks:'Kelio darbai',traffic:'Eismo spūstis',vehicle:'Transporto priemonė / gedimas',road:'Sugadintas kelias',animal:'Gyvūnas kelyje',weather:'Oro sąlygos',other:'Kitas pavojus'},cs:{accident:'Nehoda',police:'Policie / kontrola',camera:'Radar',roadworks:'Práce na silnici',traffic:'Dopravní zácpa',vehicle:'Vozidlo / porucha',road:'Poškozená silnice',animal:'Zvíře na silnici',weather:'Povětrnostní podmínky',other:'Jiné nebezpečí'},sk:{accident:'Nehoda',police:'Polícia / kontrola',camera:'Radar',roadworks:'Práce na ceste',traffic:'Zápcha',vehicle:'Vozidlo / porucha',road:'Poškodená cesta',animal:'Zviera na ceste',weather:'Poveternostné podmienky',other:'Iné nebezpečenstvo'},uk:{accident:'Аварія',police:'Поліція / контроль',camera:'Камера швидкості',roadworks:'Дорожні роботи',traffic:'Затор',vehicle:'Автомобіль / поломка',road:'Пошкоджена дорога',animal:'Тварина на дорозі',weather:'Погодні умови',other:'Інша небезпека'},ru:{accident:'Авария',police:'Полиция / контроль',camera:'Камера скорости',roadworks:'Дорожные работы',traffic:'Пробка',vehicle:'Автомобиль / поломка',road:'Повреждённая дорога',animal:'Животное на дороге',weather:'Погодные условия',other:'Другая опасность'},it:{accident:'Incidente',police:'Polizia / controllo',camera:'Autovelox',roadworks:'Lavori stradali',traffic:'Coda',vehicle:'Veicolo / guasto',road:'Strada danneggiata',animal:'Animale sulla strada',weather:'Condizioni meteo',other:'Altro pericolo'},es:{accident:'Accidente',police:'Policía / control',camera:'Radar',roadworks:'Obras',traffic:'Atasco',vehicle:'Vehículo / avería',road:'Carretera dañada',animal:'Animal en la carretera',weather:'Condiciones meteorológicas',other:'Otro peligro'}};return labels[state.language]?.[type]||labels.en[type]||type}
function localizedHelpLabel(type){const labels={pl:{flat:'Przebita opona',breakdown:'Awaria pojazdu',fuel:'Brak paliwa',accident:'Potrzebuję pomocy po zdarzeniu',medical:'Potrzebna pomoc medyczna',other:'Inna pomoc'},en:{flat:'Flat tyre',breakdown:'Vehicle breakdown',fuel:'Out of fuel',accident:'Help after an incident',medical:'Medical assistance needed',other:'Other help'},nl:{flat:'Lekke band',breakdown:'Voertuigpech',fuel:'Geen brandstof',accident:'Hulp na ongeval',medical:'Medische hulp nodig',other:'Andere hulp'},de:{flat:'Reifenpanne',breakdown:'Fahrzeugpanne',fuel:'Kein Kraftstoff',accident:'Hilfe nach einem Unfall',medical:'Medizinische Hilfe benötigt',other:'Andere Hilfe'},lt:{flat:'Pradurta padanga',breakdown:'Automobilio gedimas',fuel:'Trūksta degalų',accident:'Reikia pagalbos po įvykio',medical:'Reikia medicininės pagalbos',other:'Kita pagalba'},cs:{flat:'Píchnutá pneumatika',breakdown:'Porucha vozidla',fuel:'Došlo palivo',accident:'Potřebuji pomoc po nehodě',medical:'Potřebuji lékařskou pomoc',other:'Jiná pomoc'},sk:{flat:'Defekt pneumatiky',breakdown:'Porucha vozidla',fuel:'Došlo palivo',accident:'Potrebujem pomoc po nehode',medical:'Potrebná lekárska pomoc',other:'Iná pomoc'},uk:{flat:'Проколоте колесо',breakdown:'Поломка автомобіля',fuel:'Закінчилося пальне',accident:'Потрібна допомога після події',medical:'Потрібна медична допомога',other:'Інша допомога'},ru:{flat:'Прокол колеса',breakdown:'Поломка автомобиля',fuel:'Нет топлива',accident:'Нужна помощь после происшествия',medical:'Нужна медицинская помощь',other:'Другая помощь'},it:{flat:'Gomma forata',breakdown:'Guasto del veicolo',fuel:'Carburante esaurito',accident:'Aiuto dopo un incidente',medical:'Serve assistenza medica',other:'Altro aiuto'},es:{flat:'Neumático pinchado',breakdown:'Avería del vehículo',fuel:'Sin combustible',accident:'Necesito ayuda tras un incidente',medical:'Necesito asistencia médica',other:'Otra ayuda'}};return labels[state.language]?.[type]||labels.en[type]||type}

const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const nativeBridge=()=>window.AURIXNativeBridge||null;
const isNativeApp=()=>!!nativeBridge()?.available;
function nativeJson(v){try{return typeof v==='string'?JSON.parse(v):v}catch{return null}}
function syncNativeLocation(){const n=nativeBridge();if(!n?.available)return;const p=n.getLastLocation();if(!p||!Number.isFinite(Number(p.lat))||!Number.isFinite(Number(p.lon)))return;const pos={coords:{latitude:Number(p.lat),longitude:Number(p.lon),accuracy:Number(p.accuracy)||50,speed:Number.isFinite(Number(p.speed))?Number(p.speed):null,heading:Number.isFinite(Number(p.heading))?Number(p.heading):null}};try{updatePosition(pos,false)}catch(e){state.userPos={lat:pos.coords.latitude,lon:pos.coords.longitude,accuracy:pos.coords.accuracy};setGpsStatus('GPS: WŁ.')}}
function nativeSettingLabel(v){return v?t('Aktywne'):t('Wyłączone')}
function updateNativeSettingsUI(){const n=nativeBridge();const sec=$('#nativeSettingsSection');if(!sec)return;if(!n?.available){sec.classList.add('hidden');return}sec.classList.remove('hidden');const set=(id,on)=>{const el=$('#'+id);if(el)el.textContent=nativeSettingLabel(!!on)};set('nativeBackgroundGpsText',state.nativeBackgroundGps);set('nativeNotificationsText',state.nativeNotifications);set('nativeKeepScreenOnText',state.nativeKeepScreenOn);set('nativeAudioText',state.nativeAudio);set('nativeHapticsText',state.nativeHaptics);set('nativeAutoStartText',state.nativeAutoStart);const aa=$('#nativeAndroidAutoText');if(aa)aa.textContent=t('Obsługa przygotowana');}
function persistNativeSettings(){persist();updateNativeSettingsUI()}
async function setupNativeSettings(){const n=nativeBridge();if(!n?.available)return;try{const p=n.permissions();state.nativeNotifications=p?.notifications==='granted';state.nativeBackgroundGps=p?.backgroundLocation==='granted';state.nativeAutoStart=n.getAutoStart();}catch{}updateNativeSettingsUI();safeBind('#nativeBackgroundGps','click',async()=>{if(!state.nativeBackgroundGps){try{const p=n.permissions();if(p?.backgroundLocation==='granted'){state.nativeBackgroundGps=true;n.startBackgroundLocation();persistNativeSettings();}else{if(p?.fineLocation!=='granted'&&p?.coarseLocation!=='granted')n.requestPermissions();n.requestBackgroundLocation();showToast(t('Włącz „Zawsze zezwalaj” dla lokalizacji, jeśli Android o to poprosi.'));}}catch{n.openAppSettings()}}else{state.nativeBackgroundGps=false;n.stopBackgroundLocation();persistNativeSettings()}});safeBind('#nativeNotifications','click',()=>{if(!state.nativeNotifications)n.requestPermissions();else n.openAppSettings();setTimeout(()=>{const p=n.permissions();state.nativeNotifications=p?.notifications==='granted';persistNativeSettings()},700)});safeBind('#nativeKeepScreenOn','click',()=>{state.nativeKeepScreenOn=!state.nativeKeepScreenOn;n.setKeepScreenOn(state.nativeKeepScreenOn);persistNativeSettings()});safeBind('#nativeAudio','click',()=>{state.nativeAudio=!state.nativeAudio;persistNativeSettings()});safeBind('#nativeHaptics','click',()=>{state.nativeHaptics=!state.nativeHaptics;persistNativeSettings();if(state.nativeHaptics)n.vibrate('test')});safeBind('#nativeAutoStart','click',()=>{state.nativeAutoStart=!state.nativeAutoStart;n.setAutoStart(state.nativeAutoStart);persistNativeSettings()});safeBind('#nativeAndroidAuto','click',()=>n.openAndroidAuto());safeBind('#nativePermissions','click',()=>n.requestPermissions());if(state.nativeAutoStart)try{n.startBackgroundLocation()}catch{}syncNativeLocation()}
const uid=()=>crypto?.randomUUID?.()||'u'+Date.now()+Math.random().toString(16).slice(2);
const apiBase=()=>String(window.AURIX_CONFIG?.apiBase||'').replace(/\/$/,'');
const wsBase=()=>{const cfg=String(window.AURIX_CONFIG?.wsBase||'').trim();if(cfg)return cfg.replace(/\/$/,'');const a=apiBase();if(a)return (a.startsWith('https://')?a.replace(/^https:/,'wss:'):a.replace(/^http:/,'ws:'))+'/ws';if(typeof location!=='undefined'&&/^https?:$/.test(location.protocol))return location.origin.replace(/^http:/,'ws:').replace(/^https:/,'wss:')+'/ws';return '';}
function persist(){
 localStorage.setItem('aurixReports',JSON.stringify(state.reports.filter(r=>r.localOnly)));localStorage.setItem('aurixVotes',JSON.stringify(state.votes));localStorage.setItem('aurixDriveKm',String(state.driveKm||0));localStorage.setItem('aurixSettings',JSON.stringify({range:state.range,channel:state.channel,listen:state.listen,directionOnly:state.directionOnly,alertVolume:state.alertVolume,voiceAlerts:state.voiceAlerts,alertSoundEnabled:state.alertSoundEnabled,soundMode:state.soundMode,voiceName:state.voiceName,alertDistance:state.alertDistance,language:state.language,mapReports:accountSettings().mapReports,driveAlerts:accountSettings().driveAlerts,nativeBackgroundGps:state.nativeBackgroundGps,nativeNotifications:state.nativeNotifications,nativeKeepScreenOn:state.nativeKeepScreenOn,nativeAudio:state.nativeAudio,nativeHaptics:state.nativeHaptics,nativeAutoStart:state.nativeAutoStart}));
}
function syncAccountSettings(){}
function saveAccountSettings(){state.alertDistance=normalizeAlertDistance(state.alertDistance);state.localSettings={...accountSettings(),alertDistance:state.alertDistance};persist();syncAccountSettings();renderSettingsSummary();renderMap()}

function load(){try{state.driveKm=Number(localStorage.getItem('aurixDriveKm')||0)||0}catch{} try{const r=JSON.parse(localStorage.getItem('aurixReports')||'[]');state.reports=Array.isArray(r)?r:[]}catch{} try{state.votes=JSON.parse(localStorage.getItem('aurixVotes')||'{}')||{}}catch{} try{const s=JSON.parse(localStorage.getItem('aurixSettings')||'{}');if(s.range)state.range=s.range;if(s.channel)state.channel=s.channel;if(typeof s.listen==='boolean')state.listen=s.listen;if(typeof s.directionOnly==='boolean')state.directionOnly=s.directionOnly;if(typeof s.alertVolume==='number')state.alertVolume=Math.min(1,Math.max(.1,s.alertVolume));if(typeof s.voiceAlerts==='boolean')state.voiceAlerts=s.voiceAlerts;if(typeof s.alertSoundEnabled==='boolean')state.alertSoundEnabled=s.alertSoundEnabled;if(s.soundMode)state.soundMode=s.soundMode;if(s.voiceName)state.voiceName=s.voiceName;if(s.alertDistance)state.alertDistance=s.alertDistance;if(s.language&&LANGUAGES[s.language])state.language=s.language;if(typeof s.nativeBackgroundGps==='boolean')state.nativeBackgroundGps=s.nativeBackgroundGps;if(typeof s.nativeNotifications==='boolean')state.nativeNotifications=s.nativeNotifications;if(typeof s.nativeKeepScreenOn==='boolean')state.nativeKeepScreenOn=s.nativeKeepScreenOn;if(typeof s.nativeAudio==='boolean')state.nativeAudio=s.nativeAudio;if(typeof s.nativeHaptics==='boolean')state.nativeHaptics=s.nativeHaptics;if(typeof s.nativeAutoStart==='boolean')state.nativeAutoStart=s.nativeAutoStart;if(s.mapReports||s.driveAlerts)state.localSettings={...s,mapReports:{...DEFAULT_ACCOUNT_SETTINGS.mapReports,...(s.mapReports||{})},driveAlerts:{...DEFAULT_ACCOUNT_SETTINGS.driveAlerts,...(s.driveAlerts||{})}};}catch{} state.alertDistance=normalizeAlertDistance(state.alertDistance);applyAccountSettings({...accountSettings(),alertDistance:state.alertDistance});state.localSettings={...accountSettings(),alertDistance:state.alertDistance};}
function nav(id){$$('.screen').forEach(x=>x.classList.remove('active'));$('#'+id)?.classList.add('active');$$('.bottom-nav button').forEach(b=>b.classList.toggle('active',b.dataset.nav===id));if(id==='map'&&state.map)setTimeout(()=>{state.map.invalidateSize();renderMap()},80);if(id==='cb'&&state.cbOnline){connectCbRealtime();}else if(id!=='cb'&&state.cbOnline){leaveCbOnline();}if(state.driving)updateGlobalDriveAlert(state.currentAlert,state.currentAlert?nearestAlert()?.distanceStep:null);}
function renderReportButtons(){const g=$('#reportGrid');g.innerHTML='';Object.entries(REPORT_TYPES).filter(([key])=>!key.startsWith('help_')).forEach(([key,t])=>{const b=document.createElement('button');b.className='report-choice';b.style.setProperty('--report-color',t.color);b.innerHTML=`<span>${t.icon}</span><strong>${localizedReportLabel(key)}</strong>`;b.onclick=()=>REPORT_VARIANTS[key]?openReportVariantModal(key):createReport(key);g.appendChild(b)})}
function openReportVariantModal(type){const g=$('#reportVariantGrid');const title=$('#reportVariantTitle');if(!g||!title)return;const rt=REPORT_TYPES[type];title.textContent=`${t('ZGŁOŚ')} ${localizedReportLabel(type).toLowerCase()}`;g.innerHTML='';(REPORT_VARIANTS[type]||[]).forEach(([variant,label,icon,direction])=>{const b=document.createElement('button');b.className='report-choice';b.style.setProperty('--report-color',rt.color);b.innerHTML=`<span>${icon}</span><strong>${label}</strong>`;b.onclick=()=>createReport(type,variant,direction);g.appendChild(b)});$('#reportModal').classList.add('hidden');$('#reportVariantModal').classList.remove('hidden')}
async function createReport(type,variant=null,direction='same'){let p;try{p=await locate(true)}catch{showToast('Nie udało się pobrać aktualnej pozycji GPS — zgłoszenie nie zostało zapisane');return}const now=Date.now();let h=hasUsableHeading()?Math.round(state.heading):null;if(direction==='opposite'&&h!==null)h=(h+180)%360;const r={id:uid(),type,variant:variant||null,direction:direction||'same',lat:p.coords.latitude,lon:p.coords.longitude,accuracy:Number.isFinite(p.coords.accuracy)?Math.round(p.coords.accuracy):null,heading:h,createdAt:now,reportedAt:new Date(now).toISOString(),confirm:0,reject:0,text:variant?(REPORT_VARIANT_LABELS[variant]||REPORT_TYPES[type].label):REPORT_TYPES[type].label,localOnly:true,active:true};state.userPos={lat:r.lat,lon:r.lon,accuracy:r.accuracy};state.reports.unshift(r);persist();$('#reportModal').classList.add('hidden');$('#reportVariantModal').classList.add('hidden');const result=await post('/reports',r);if(result?.ok){r.localOnly=false;}else if(apiBase()){state.reports=state.reports.filter(x=>x.id!==r.id);persist();showToast('Nie udało się wysłać zgłoszenia do serwera');return;}renderAll();showToast(`${REPORT_TYPES[type].icon} ${reportDisplayLabel(r)} — ${t('zapisano pozycję GPS')}`)}
async function post(path,data){if(!apiBase())return null;try{const res=await fetch(apiBase()+path,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});const body=await res.json().catch(()=>null);return {ok:res.ok,status:res.status,data:body};}catch{return {ok:false,status:0,data:null}}}
async function getReports(){if(!apiBase())return;try{const res=await fetch(apiBase()+'/reports/nearby?lat='+(state.userPos?.lat||0)+'&lon='+(state.userPos?.lon||0)+'&radius='+Math.max(1,alertMaxDistanceKm()));if(!res.ok)return;const data=await res.json();if(Array.isArray(data)){const local=state.reports.filter(r=>r.localOnly);state.reports=[...data,...local]}}catch{}}

// Network refresh is throttled so GPS callbacks can safely trigger background refreshes.
let networkRefreshInFlight=false;
let lastNetworkRefreshAt=0;
async function refreshNetworkData(force=false){
  if(!apiBase()||!state.userPos||networkRefreshInFlight)return;
  const now=Date.now();
  if(!force&&now-lastNetworkRefreshAt<7000)return;
  networkRefreshInFlight=true;
  lastNetworkRefreshAt=now;
  try{
    await Promise.all([getReports(),getCameras(),getHelpRequests(),getCbPresence()]);
    renderAll();
    if(state.driving)updateAlertEngine();
  }catch{}finally{networkRefreshInFlight=false;}
}
async function getCbPresence(){if(!apiBase()||!state.userPos){state.cbDrivers=0;return}try{const q=new URLSearchParams({lat:state.userPos.lat,lon:state.userPos.lon,range:state.range,channel:state.channel,deviceId:getUserId()});const res=await fetch(apiBase()+'/cb/presence?'+q);if(res.ok){const data=await res.json();state.cbDrivers=Number(data.count)||0}}catch{state.cbDrivers=0}updateCounts()}
async function getCameras(){if(!apiBase())return;try{const res=await fetch(apiBase()+'/speed-cameras/nearby?lat='+(state.userPos?.lat||0)+'&lon='+(state.userPos?.lon||0)+'&radius='+Math.max(1,alertMaxDistanceKm()));if(res.ok){const data=await res.json();if(Array.isArray(data))state.cameras=data}}catch{}}
function ageText(ts){const m=Math.max(0,Math.floor((Date.now()-ts)/60000));return m<1?'teraz':m===1?'1 min temu':`${m} min temu`}
function distanceKm(a,b){if(!a||!b)return Infinity;const lat1=Number(a.lat),lon1=Number(a.lon),lat2=Number(b.lat),lon2=Number(b.lon);if(![lat1,lon1,lat2,lon2].every(Number.isFinite))return Infinity;const R=6371.0088;const toRad=Math.PI/180;const dLat=(lat2-lat1)*toRad,dLon=(lon2-lon1)*toRad;const p1=lat1*toRad,p2=lat2*toRad;const h=Math.sin(dLat/2)**2+Math.cos(p1)*Math.cos(p2)*Math.sin(dLon/2)**2;return R*2*Math.atan2(Math.sqrt(Math.min(1,h)),Math.sqrt(Math.max(0,1-h)))}
function distanceMeters(a,b){const km=distanceKm(a,b);return Number.isFinite(km)?km*1000:Infinity;}
function bearing(a,b){const y=Math.sin((b.lon-a.lon)*Math.PI/180)*Math.cos(b.lat*Math.PI/180);const x=Math.cos(a.lat*Math.PI/180)*Math.sin(b.lat*Math.PI/180)-Math.sin(a.lat*Math.PI/180)*Math.cos(b.lat*Math.PI/180)*Math.cos((b.lon-a.lon)*Math.PI/180);return (Math.atan2(y,x)*180/Math.PI+360)%360}
function angleDiff(a,b){return Math.abs(((a-b+540)%360)-180)}
const REPORT_VARIANTS={
 traffic:[['traffic_medium','Średni korek','🚗🚗🚗','same'],['traffic_heavy','Duży','🚗🚗🚗','same'],['traffic_jam','Zator','🚗🚗🚗','same'],['traffic_opposite','Druga strona','🚗↔️','opposite']],
 accident:[['accident','Wypadek','💥🚙','same'],['accident_pileup','Karambol','💥🚗','same'],['accident_opposite','Druga strona','🚙💥','opposite']],
 police:[['police','Policja','👮','same'],['police_camera','Przenośny fotoradar','📸','same'],['police_hidden','Ukryta','👮','same'],['police_opposite','Druga strona','👮↔️','opposite']],
 road:[['road_damage','Uszkodzona droga','⚠️🛣️','same'],['road_pothole','Ubytek nawierzchni','⚠️','same'],['road_blocked','Zablokowany pas','🚧','same'],['road_opposite','Druga strona','🛣️↔️','opposite']],
 vehicle:[['vehicle_breakdown','Awaria pojazdu','🔧🚗','same'],['vehicle_shoulder','Na poboczu','🚗⚠️','same'],['vehicle_opposite','Druga strona','🚗↔️','opposite']],
 roadworks:[['roadworks','Roboty drogowe','🚧','same'],['roadworks_opposite','Druga strona','🚧↔️','opposite'],['roadworks_blocked','Zablokowany pas ruchu','🚧🛣️','same']]
};
const REPORT_VARIANT_LABELS={
 traffic_medium:'Średni korek',traffic_heavy:'Duży',traffic_jam:'Zator',traffic_opposite:'Druga strona',accident:'Wypadek',accident_pileup:'Karambol',accident_opposite:'Druga strona',
 police:'Policja',police_camera:'Przenośny fotoradar',police_hidden:'Ukryta',police_opposite:'Druga strona',
 road_damage:'Uszkodzona droga',road_pothole:'Ubytek nawierzchni',road_blocked:'Zablokowany pas',road_opposite:'Druga strona',
 vehicle_breakdown:'Awaria pojazdu',vehicle_shoulder:'Na poboczu',vehicle_opposite:'Druga strona',roadworks:'Roboty drogowe',roadworks_opposite:'Druga strona',roadworks_blocked:'Zablokowany pas ruchu'
};
function reportDisplayLabel(r){return r?.variant&&REPORT_VARIANT_LABELS[r.variant]?REPORT_VARIANT_LABELS[r.variant]:localizedReportLabel(r?.type);}
const DIRECTIONAL_ALERT_TYPES=new Set(['traffic','accident','police','road','vehicle','roadworks']);
function hasUsableHeading(){return Number.isFinite(state.heading)&&state.heading>=0&&state.heading<=360}
function reportHeading(r){const h=Number(r?.heading ?? r?.course ?? r?.bearing);return Number.isFinite(h)&&h>=0&&h<=360?h:null}
function isAhead(r){if(!state.userPos)return false;const toReport=bearing(state.userPos,{lat:r.lat,lon:r.lon});if(!hasUsableHeading())return true;return angleDiff(state.heading,toReport)<=100}
function isSameDirection(r){if(!DIRECTIONAL_ALERT_TYPES.has(r.type))return true;if(!state.userPos)return false;const rh=reportHeading(r);if(!hasUsableHeading())return true;const toReport=bearing(state.userPos,{lat:r.lat,lon:r.lon});if(angleDiff(state.heading,toReport)>100)return false;if(rh!==null && angleDiff(state.heading,rh)>100)return false;return true}
function alertMaxDistanceKm(){return alertDistanceKm()}
function alertCandidateAllowed(type){return accountSettings().driveAlerts[type]!==false}
function nearestAlert(){
 if(!state.userPos)return null;
 const maxMeters=alertDistanceMeters();
 const reports=state.reports
  .map(r=>({...r,distance:distanceMeters(state.userPos,{lat:r.lat,lon:r.lon})}))
  .filter(r=>{
   const d=r.distance;
   if(state.dismissedAlerts.has(r.id)){
    if(d>100)state.dismissedAlerts.delete(r.id);else return false;
   }
   return r.active!==false&&!state.passed.has(r.id)&&alertCandidateAllowed(r.type)&&d<=maxMeters&&isAhead(r)&&isSameDirection(r);
  });
 const cameras=accountSettings().driveAlerts.camera!==false
  ?state.cameras
   .map(c=>({...c,id:'cam_'+(c.id||c.lat+'_'+c.lon),type:'camera',camera:true,priority:3,distance:distanceMeters(state.userPos,{lat:c.lat,lon:c.lon})}))
   .filter(c=>c.distance<=maxMeters&&isAhead(c))
  :[];
 return [...reports,...cameras].sort((a,b)=>a.distance-b.distance)[0]||null;
}
function reportIcon(type){const t=REPORT_TYPES[type];return L.divIcon({className:'custom-marker',html:`<div class="report-marker" style="--c:${t.color}">${t.icon}</div>`,iconSize:[44,44],iconAnchor:[22,22]})}
function cameraIcon(){return L.divIcon({className:'custom-marker',html:`<div class="camera-marker">📷</div>`,iconSize:[42,42],iconAnchor:[21,21]})}
function initMap(){state.map=L.map('mapCanvas',{zoomControl:true,attributionControl:true}).setView([52.1,19.4],6);L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'© OpenStreetMap contributors'}).addTo(state.map);state.reportLayer=L.layerGroup().addTo(state.map);state.cameraLayer=L.layerGroup().addTo(state.map);renderMap()}
function renderMap(){if(!state.map)return;state.reportLayer.clearLayers();state.cameraLayer.clearLayers();state.reports.filter(r=>r.active!==false&&accountSettings().mapReports[r.type]!==false&&(state.selectedFilter==='all'||r.type===state.selectedFilter)).forEach(r=>{const m=L.marker([r.lat,r.lon],{icon:reportIcon(r.type)}).addTo(state.reportLayer);m.on('click',()=>showDetail(r))});state.helpRequests.filter(h=>h.active!==false&&state.userPos&&distanceKm(state.userPos,{lat:h.lat,lon:h.lon})<=10).forEach(h=>{const t=REPORT_TYPES[h.type]||REPORT_TYPES.other;const m=L.marker([h.lat,h.lon],{icon:L.divIcon({className:'custom-marker',html:`<div class="report-marker" style="--c:${t.color}">${t.icon}</div>`,iconSize:[44,44],iconAnchor:[22,22]})}).addTo(state.reportLayer);m.bindPopup(`<b>${localizedHelpLabel(h.helpType||String(h.type||'').replace('help_',''))}</b><br>${formatDistance(h)} ${t('od Ciebie')}`)});if(accountSettings().mapReports.camera!==false)state.cameras.forEach(c=>{const m=L.marker([c.lat,c.lon],{icon:cameraIcon()}).addTo(state.cameraLayer);m.on('click',()=>showCamera(c))});updateCounts()}
function showDetail(r){const rt=REPORT_TYPES[r.type],el=$('#mapDetail');el.classList.remove('hidden');const voted=!!state.votes[r.id];el.style.setProperty('--detail-color',rt.color);el.innerHTML=`<div class="detail-top"><div class="detail-icon" style="background:${rt.color}">${rt.icon}</div><div><b>${localizedReportLabel(r.type).toUpperCase()}</b><div>${formatDistance(r)} • ${ageText(r.createdAt)}</div><small>${r.confirm||0} ${t('potwierdzeń')} • ${localizedReportLabel(r.type)}</small></div><button id="closeDetail" class="close-round">×</button></div><div class="detail-actions"><button id="confirmReport" class="primary-btn" style="background:${rt.color}" ${voted?'disabled':''}>${voted?(state.votes[r.id]==='confirm'?`✓ ${t('POTWIERDZONE')}`:`✓ ${t('POTWIERDŹ')}`): `✓ ${t('POTWIERDŹ')}`}</button><button id="rejectReport" class="secondary-btn" ${voted?'disabled':''}>${voted?(state.votes[r.id]==='reject'?`✕ ${t('ODWOŁANE')}`:`✕ ${t('ODWOŁAJ')}`):`✕ ${t('ODWOŁAJ')}`}</button></div>`;$('#closeDetail').onclick=()=>el.classList.add('hidden');$('#confirmReport').onclick=()=>respondReport(r,true);$('#rejectReport').onclick=()=>respondReport(r,false)}
async function respondReport(r,confirm){const userId=getUserId();if(state.votes[r.id]){showToast('Już odpowiedziałeś na to zdarzenie');$('#mapDetail').classList.add('hidden');return}const result=await post(`/reports/${r.id}/${confirm?'confirm':'reject'}`,{id:r.id,userId,action:confirm?'confirm':'reject'});if(!result?.ok){showToast(result?.status===409?'Już odpowiedziałeś na to zdarzenie':'Nie udało się zapisać odpowiedzi na serwerze');return;}state.votes[r.id]=confirm?'confirm':'reject';const updated=result.data;if(updated){Object.assign(r,updated);}state.dismissedAlerts.add(r.id);if(state.currentAlert?.id===r.id){state.currentAlert=null;renderActiveAlert(null);updateGlobalDriveAlert(null,null)}persist();showToast(confirm?t('Zgłoszenie potwierdzone'):t('Zgłoszenie odwołane'));$('#mapDetail').classList.add('hidden');renderAll();}
function showCamera(c){const el=$('#mapDetail');el.classList.remove('hidden');el.style.setProperty('--detail-color','#8e44ff');el.innerHTML=`<div class="detail-top"><div class="detail-icon camera-bg">📷</div><div><b>FOTORADAR</b><div>${(c.type||'STATIC_SPEED_CAMERA').replaceAll('_',' ')}</div><small>Limit: ${c.limit??'—'} km/h • ${c.road||'—'}</small></div><button id="closeDetail" class="close-round">×</button></div>`;$('#closeDetail').onclick=()=>el.classList.add('hidden')}
function renderFilters(){const box=$('#mapFilters');box.innerHTML='';[['all',t('Wszystkie'),'#fff'],...Object.entries(REPORT_TYPES).map(([k,t])=>[k,localizedReportLabel(k),t.color])].forEach(([k,label,color])=>{const b=document.createElement('button');b.className='filter '+(state.selectedFilter===k?'active':'');b.textContent=k==='all'?t('Wszystkie'):`${REPORT_TYPES[k].icon} ${label}`;b.style.color=color;b.onclick=()=>{state.selectedFilter=k;renderFilters();renderMap()};box.appendChild(b)})}
function formatDistance(r){if(!state.userPos)return '—';const d=distanceMeters(state.userPos,{lat:r.lat,lon:r.lon});if(!Number.isFinite(d))return '—';return d<1000?`${Math.round(d)} m`:`${(d/1000).toFixed(1)} km`}
function getAheadAlerts(limit=5){
 if(!state.userPos)return [];
 const maxMeters=alertDistanceMeters();
 const reports=state.reports.map(r=>({...r,distance:distanceMeters(state.userPos,{lat:r.lat,lon:r.lon})})).filter(r=>{const d=r.distance;if(state.dismissedAlerts.has(r.id)){if(d>100)state.dismissedAlerts.delete(r.id);else return false}return r.active!==false&&!state.passed.has(r.id)&&accountSettings().mapReports[r.type]!==false&&alertCandidateAllowed(r.type)&&d<=maxMeters&&isAhead(r)&&isSameDirection(r)});
 const cameras=accountSettings().mapReports.camera!==false?state.cameras.map(c=>({...c,id:'cam_'+(c.id||c.lat+'_'+c.lon),type:'camera',camera:true,distance:distanceMeters(state.userPos,{lat:c.lat,lon:c.lon})})).filter(c=>c.distance<=maxMeters&&isAhead(c)) : [];
 return [...reports,...cameras].sort((a,b)=>a.distance-b.distance).slice(0,limit);
}
function renderHomeAheadAlerts(){
 const box=$('#homeAheadAlerts'),count=$('#aheadAlertCount'); if(!box)return;
 const items=getAheadAlerts(5);
 if(count)count.textContent=items.length;
 if(!items.length){box.innerHTML=`<div class="ahead-alert-empty">${t('Brak alertów przed Tobą')}</div>`;return}
 box.innerHTML='';
 items.forEach(r=>{const rt=r.camera?{color:'#8E44FF',icon:'📷'}:(REPORT_TYPES[r.type]||REPORT_TYPES.other);const b=document.createElement('button');b.className='ahead-alert-item';b.style.setProperty('--alert-color',rt.color);b.innerHTML=`<span class="ahead-alert-icon" style="background:${rt.color}">${rt.icon}</span><span class="ahead-alert-info"><strong>${r.camera?t('Fotoradar'):reportDisplayLabel(r)}</strong><small>${alertDistanceText(r.distance)}</small></span>`;b.onclick=()=>{nav('map');setTimeout(()=>r.camera?showCamera(r):showDetail(r),100)};box.appendChild(b)});
}
function renderLists(){const list=$('#alertList'),home=$('#homeReports');list.innerHTML='';home.innerHTML='';renderHomeAheadAlerts();const active=state.reports.filter(r=>r.active!==false);if(!active.length){list.innerHTML=`<div class="empty-state">${t('Brak aktywnych zgłoszeń.')}</div>`;home.innerHTML=`<div class="empty-state compact">${t('Brak aktywnych zgłoszeń w pobliżu.')}</div>`;return}active.forEach(r=>{const rt=REPORT_TYPES[r.type];const html=`<div class="color-dot" style="background:${rt.color}"></div><div><strong>${rt.icon} ${localizedReportLabel(r.type)}</strong><small>${formatDistance(r)} • ${ageText(r.createdAt)} • ${r.confirm||0} ${t('potwierdzeń')}</small></div>`;const a=document.createElement('button');a.className='alert-item';a.innerHTML=html;a.onclick=()=>{nav('map');setTimeout(()=>showDetail(r),100)};list.appendChild(a);if(home.children.length<3){const h=a.cloneNode(true);h.onclick=()=>{nav('map');setTimeout(()=>showDetail(r),100)};home.appendChild(h)}})}
function updateCounts(){const active=state.reports.filter(r=>r.active!==false);$('#nearbyCount').textContent=active.length;$('#cameraCount').textContent=state.cameras.length;$('#cbDrivers').textContent=state.cbDrivers;$('#driveCamera').textContent=state.cameras.length+' '+t('w pobliżu');$('#driveAlert').textContent=active.length+' '+t('aktywne');renderOnlineUsers()}
function setUserMarker(){if(!state.map||!state.userPos)return;const ll=[state.userPos.lat,state.userPos.lon];if(state.userMarker)state.userMarker.setLatLng(ll);else state.userMarker=L.marker(ll,{icon:L.divIcon({className:'custom-marker',html:'<div class="user-marker">➤</div>',iconSize:[34,34],iconAnchor:[17,17]})}).addTo(state.map)}
function gpsErrorText(err){
 if(err?.code===1)return 'Dostęp do lokalizacji jest zablokowany. Zezwól tej stronie na dostęp do lokalizacji w ustawieniach przeglądarki.';
 if(err?.code===2)return 'Telefon nie zwrócił pozycji. Włącz lokalizację/GPS i spróbuj ponownie.';
 if(err?.code===3)return 'Nie udało się pobrać pozycji w wyznaczonym czasie. Spróbuj ponownie na zewnątrz lub przy lepszym sygnale.';
 return 'Nie udało się pobrać lokalizacji. Spróbuj ponownie.';
}
function locate(fresh=false){
 if(!window.isSecureContext){const e=new Error('GPS wymaga bezpiecznego połączenia HTTPS.');showToast(e.message);return Promise.reject(e);}
 if(!navigator.geolocation){const e=new Error('Ta przeglądarka nie obsługuje lokalizacji.');showToast(e.message);return Promise.reject(e);}
 const maxAge=fresh?0:5000;
 const request=(high,timeout)=>new Promise((resolve,reject)=>{
  try{navigator.geolocation.getCurrentPosition(resolve,reject,{enableHighAccuracy:high,timeout,maximumAge:maxAge});}
  catch(e){reject(e);}
 });
 return request(true,15000).catch(err=>{
  if(err?.code===1)throw err;
  return request(false,20000);
 }).then(pos=>{
  if(!pos?.coords||!Number.isFinite(pos.coords.latitude)||!Number.isFinite(pos.coords.longitude))throw new Error('Odebrano nieprawidłową pozycję GPS.');
  try{updatePosition(pos,true);}catch(uiError){
   console.error('[AURIX] Błąd po odebraniu GPS:',uiError);
   state.userPos={lat:pos.coords.latitude,lon:pos.coords.longitude,accuracy:Number(pos.coords.accuracy)||null};
   setGpsStatus('GPS: WŁ.');
  }
  localStorage.setItem('aurixGpsGranted','1');
  return pos;
 }).catch(err=>{
  console.error('[AURIX] Geolocation error:',err);
  setGpsStatus(err?.code===1?'GPS: ZABLOKOWANY':err?.code===2?'GPS: BRAK POZYCJI':err?.code===3?'GPS: BRAK SYGNAŁU':'GPS: BŁĄD');
  showToast(gpsErrorText(err));
  throw err;
 });
}
function updatePosition(pos,center=false){const next={lat:pos.coords.latitude,lon:pos.coords.longitude,accuracy:pos.coords.accuracy};const previousPos=state.userPos?{lat:state.userPos.lat,lon:state.userPos.lon}:null;if(state.driving&&state.driveLastPos){const d=distanceKm(state.driveLastPos,next);if(d>0&&d<0.2){state.driveKm+=d;localStorage.setItem('aurixDriveKm',String(state.driveKm));}}if(state.driving)state.driveLastPos={lat:next.lat,lon:next.lon};const gpsHeading=Number(pos.coords.heading);if(Number.isFinite(gpsHeading)&&gpsHeading>=0&&gpsHeading<=360)state.heading=gpsHeading;else if(previousPos&&distanceKm(previousPos,next)>0.005)state.heading=bearing(previousPos,next);state.userPos=next;state.speed=Number.isFinite(pos.coords.speed)?Math.max(0,pos.coords.speed*3.6):0;$('#gpsStatus').textContent=t('GPS: ON');$('#gpsText').textContent=t('Aktywna');$('#speedValue').textContent=Math.round(state.speed);setUserMarker();if(center&&state.map)state.map.setView([state.userPos.lat,state.userPos.lon],15);updateAlertEngine();renderLists();renderMap();refreshNetworkData();}
function watchGps(){
 if(!navigator.geolocation||state.watchId!==null)return;
 state.watchId=navigator.geolocation.watchPosition(
  pos=>updatePosition(pos,false),
  err=>{
   if(err?.code===1) setGpsStatus('Brak zgody na lokalizację');
   else if(err?.code===2) setGpsStatus('Nie udało się ustalić pozycji');
   else if(err?.code===3) setGpsStatus('Oczekiwanie na GPS…');
  },
  {enableHighAccuracy:true,maximumAge:5000,timeout:20000}
 );
}
function startDrive(){state.driveLastPos=state.userPos?{...state.userPos}:null;if(!state.userPos){locate();showToast(t('Pobieram lokalizację…'));}state.driving=true;const n=nativeBridge();if(n?.available){n.setDriveState(true);if(state.nativeBackgroundGps)try{n.startBackgroundLocation()}catch{}if(state.nativeKeepScreenOn)try{n.setKeepScreenOn(true)}catch{}}updateOnlinePresenceMode();nav('drive');$('#startDrive').innerHTML=`<span>●</span><div><strong>${t('JAZDA AKTYWNA')}</strong><small>${t('Alerty są aktywne')}</small></div>`;showToast(t('Tryb jazdy aktywny'));updateAlertEngine()}
function stopDrive(){state.driving=false;state.driveLastPos=null;const n=nativeBridge();if(n?.available){n.setDriveState(false);if(state.nativeBackgroundGps)try{n.stopBackgroundLocation()}catch{}if(state.nativeKeepScreenOn)try{n.setKeepScreenOn(false)}catch{}}updateOnlinePresenceMode();state.currentAlert=null;$('#globalDriveAlert')?.classList.add('hidden');nav('home');$('#startDrive').innerHTML=`<span>▶</span><div><strong>${t('ROZPOCZNIJ JAZDĘ')}</strong><small>${t('GPS + alerty w pobliżu')}</small></div>`;renderActiveAlert(null)}
function showToast(msg){msg=typeof msg==='string'?t(msg):msg;let toast=document.querySelector('.toast');if(!toast){toast=document.createElement('div');toast.className='toast';document.body.appendChild(toast)}toast.textContent=msg;toast.classList.add('show');clearTimeout(toast._x);toast._x=setTimeout(()=>toast.classList.remove('show'),2400)}
function playAlertSound(level=1,distance=Infinity){if(!state.alertSoundEnabled||state.soundMode==='off'||(state.soundMode==='warnings'&&level<3)||(state.soundMode==='limited'&&level<3))return;const n=nativeBridge();if(n?.available&&state.nativeAudio){try{n.playAlert(level,state.alertVolume,distance)}catch{}return}try{const C=window.AudioContext||window.webkitAudioContext;if(!C||state.alertVolume<=0)return;const c=state.audioContext||(state.audioContext=new C());if(c.state==='suspended')c.resume();const now=c.currentTime;/* AURIX: >100 m = one BIK; <=100 m = two very fast BIKBIK. */const gainLevel=Math.min(.98,.72*state.alertVolume+.22);const makeBeep=(start)=>{const o=c.createOscillator(),g=c.createGain();o.type='sine';o.frequency.setValueAtTime(1120,start);o.frequency.exponentialRampToValueAtTime(1240,start+.055);o.connect(g);g.connect(c.destination);g.gain.setValueAtTime(.0001,start);g.gain.exponentialRampToValueAtTime(gainLevel,start+.006);g.gain.exponentialRampToValueAtTime(.0001,start+.105);o.start(start);o.stop(start+.11)};makeBeep(now);if(Number(distance)<=100){makeBeep(now+.103)}}catch{}}
function alertDistanceText(distance){const d=Math.max(0,Number(distance)||0);const prep=({pl:'za',en:'in',nl:'over',de:'in',lt:'po',cs:'za',sk:'o',uk:'через',ru:'через',it:'tra',es:'en'}[state.language]||'in');if(d>=1000){const km=d/1000;const n=km<10?Math.round(km*10)/10:Math.round(km);const unit=({pl:n===1?'kilometr':'kilometrów',en:n===1?'kilometre':'kilometres',nl:n===1?'kilometer':'kilometer',de:n===1?'Kilometer':'Kilometern',lt:'kilometrų',cs:n===1?'kilometr':'kilometry',sk:n===1?'kilometer':'kilometrov',uk:n===1?'кілометр':'кілометрів',ru:n===1?'километр':'километров',it:n===1?'chilometro':'chilometri',es:n===1?'kilómetro':'kilómetros'}[state.language]||'kilometres');return `${prep} ${n} ${unit}`}const n=Math.round(d);const unit=({pl:n===1?'metr':'metrów',en:n===1?'metre':'metres',nl:n===1?'meter':'meter',de:n===1?'Meter':'Metern',lt:'metrų',cs:n===1?'metr':'metry',sk:n===1?'meter':'metrov',uk:n===1?'метр':'метрів',ru:n===1?'метр':'метров',it:n===1?'metro':'metri',es:n===1?'metro':'metros'}[state.language]||'metres');return `${prep} ${n} ${unit}`}

function speakAlert(r,distance){if(!state.voiceAlerts||state.soundMode==='off'||(state.soundMode==='limited'&&distance>300)||(state.soundMode==='warnings'&&Number(r.priority||0)<3))return;const distancePhrase=alertDistanceText(distance);const msg=`${t('Uwaga.')} ${alertVoiceLabel(r.type)} ${distancePhrase}.`;const n=nativeBridge();if(n?.available&&state.nativeAudio){try{n.speak(msg,voiceLang(),state.alertVolume)}catch{}return}if(!('speechSynthesis'in window))return;try{window.speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(msg);u.lang=voiceLang();u.rate=.96;u.pitch=1;u.volume=state.alertVolume;const voices=speechSynthesis.getVoices();const wanted=voices.find(v=>state.voiceName&&v.name===state.voiceName)||voices.find(v=>v.lang?.toLowerCase()===voiceLang().toLowerCase())||voices.find(v=>v.lang?.toLowerCase().startsWith(state.language));if(wanted)u.voice=wanted;window.speechSynthesis.speak(u)}catch{}}
function updateAlertEngine(){if(!state.driving||!state.userPos)return;const r=nearestAlert();if(!r){state.currentAlert=null;renderActiveAlert(null);return}/* Nowe zgłoszenie w miejscu kierowcy nie jest uznawane za minięte. */state.currentAlert=r;renderActiveAlert(r,r.distance);const step=alertThresholdsMeters().find(s=>r.distance<=s);const previous=state.alertStates.get(r.id);if(step&&previous!==step){state.alertStates.set(r.id,step);const priority=REPORT_TYPES[r.type]?.priority||1;playAlertSound(priority,r.distance);if(state.nativeHaptics){try{nativeBridge()?.vibrate('alert')}catch{}}speakAlert(r,r.distance);notifyAlert(r,r.distance)}if(r){try{nativeBridge()?.setCurrentAlert(reportDisplayLabel(r),r.distance,REPORT_TYPES[r.type]?.priority||1)}catch{}}const prevDistance=state.alertDistanceHistory.get(r.id);state.alertDistanceHistory.set(r.id,r.distance);/* Alert uznajemy za minięty dopiero po realnym oddaleniu się od niego. Samo 0–15 m nie oznacza minięcia, bo kierowca może stać w miejscu. */if(prevDistance!==undefined&&prevDistance<15&&r.distance>25&&r.distance>prevDistance+5){state.passed.add(r.id);state.alertStates.delete(r.id);state.alertDistanceHistory.delete(r.id);state.currentAlert=null;renderActiveAlert(null);showToast(`${REPORT_TYPES[r.type]?.icon||'⚠'} Zgłoszenie minięte`);}}
function notifyAlert(r,distance){const rt=REPORT_TYPES[r.type];const label=reportDisplayLabel(r);const dist=alertDistanceText(distance);showToast(`${rt.icon} ${label} — ${dist}`);const n=nativeBridge();if(n?.available&&state.nativeNotifications)try{n.postAlertNotification(label,dist)}catch{}if('Notification'in window&&Notification.permission==='granted')try{new Notification(`${label} — ${dist}`,{body:t('Zbliżasz się do zgłoszenia.'),tag:'aurix-'+r.id})}catch{}}
function updateGlobalDriveAlert(r,distance){const el=$('#globalDriveAlert');if(!el)return;if(!state.driving||!r||distance===null||distance===undefined||!$('#cb')?.classList.contains('active')){el.classList.add('hidden');return}const rt=REPORT_TYPES[r.type];const dist=alertDistanceText(distance);el.classList.remove('hidden');el.style.setProperty('--alert-color',rt.color);el.innerHTML=`<div class="gda-inner"><div class="gda-icon">${rt.icon}</div><div><small>${t('ALERT PRZED TOBĄ')}</small><strong>${reportDisplayLabel(r)}</strong><b>${dist}</b></div>${r.camera?'':`<div class="gda-actions"><button id="globalConfirm" style="background:${rt.color}">✓</button><button id="globalReject" style="background:#242a33">✕</button></div>`}</div>`;if(!r.camera){$('#globalConfirm').onclick=()=>respondReport(r,true);$('#globalReject').onclick=()=>respondReport(r,false)}}
function renderActiveAlert(r,distance){const el=$('#activeAlert');if(!r){el.className='active-alert empty';el.innerHTML=t('Brak alertu przed Tobą');updateGlobalDriveAlert(null,null);return}const rt=r.camera?{color:'#8E44FF',icon:'📷',priority:3,label:'Fotoradar'}:(REPORT_TYPES[r.type]||REPORT_TYPES.other);const dist=alertDistanceText(distance);el.className='active-alert';el.style.setProperty('--alert-color',rt.color);el.innerHTML=`<div class="alert-icon" style="background:${rt.color}">${rt.icon}</div><div><small>${t('ALERT PRZED TOBĄ')}</small><strong>${r.camera?t('Fotoradar'):reportDisplayLabel(r)}</strong><b>${dist}</b></div>${r.camera?'':`<div class="alert-actions"><button id="driveConfirm" style="background:${rt.color}">✓ ${t('POTWIERDŹ')}</button><button id="driveReject">✕ ${t('ODWOŁAJ')}</button></div>`}`;if(!r.camera){$('#driveConfirm').onclick=()=>respondReport(r,true);$('#driveReject').onclick=()=>respondReport(r,false)}updateGlobalDriveAlert(r,distance)}
async function requestNotifications(){const n=nativeBridge();if(n?.available){try{n.requestPermissions();setTimeout(()=>{const p=n.permissions();state.nativeNotifications=p?.notifications==='granted';$('#notificationText').textContent=state.nativeNotifications?t('Aktywne'):t('Odmówione');persistNativeSettings()},700)}catch{}return}if(!('Notification'in window)){showToast('Powiadomienia nie są dostępne');return}const p=await Notification.requestPermission();$('#notificationText').textContent=p==='granted'?'Aktywne':'Odmówione'}
async function requestMic(){const n=nativeBridge();if(n?.available){try{n.requestPermissions();showToast(t('Zarządzaj uprawnieniem mikrofonu w Androidzie'))}catch{}return}try{const s=await navigator.mediaDevices.getUserMedia({audio:true});s.getTracks().forEach(t=>t.stop());$('#voiceText').textContent='Aktywny';showToast('Mikrofon aktywny')}catch{showToast('Mikrofon nie został udostępniony')}}
function getUserId(){return localStorage.getItem('aurixAnonId')||(()=>{const id=uid();localStorage.setItem('aurixAnonId',id);return id})()}
function setupPTT(){const ptt=$('#ptt');if(!ptt)return;const start=async e=>{e.preventDefault();if(state.recording)return;try{await startCbTalk();state.recording=true;ptt.classList.add('recording');$('#pttState').textContent='NADAWANIE — PUŚĆ, ABY ZAKOŃCZYĆ';}catch{}};const stop=e=>{e.preventDefault();if(!state.recording)return;state.recording=false;stopCbTalk();ptt.classList.remove('recording');$('#pttState').textContent=`Kanał ${state.channel}`;};ptt.addEventListener('pointerdown',start);['pointerup','pointercancel','pointerleave'].forEach(x=>ptt.addEventListener(x,stop));}
function openChannelModal(){const m=$('#channelModal'),g=$('#channelGrid');g.innerHTML='';for(let i=1;i<=40;i++){const b=document.createElement('button');b.className='channel-choice '+(i===state.channel?'selected':'');b.textContent=i;b.onclick=()=>{state.channel=i;$('#channelValue').textContent=i;$('#pttState').textContent=`${t('Kanał')} ${i}`;persist();m.classList.add('hidden');renderCbTitle();if(state.cbOnline)sendPresence();if(state.cbOnline&&$('#cb')?.classList.contains('active')){connectCbRealtime();}showToast(`${t('Kanał')} ${i} ${t('Kanał aktywny')}`)};g.appendChild(b)}m.classList.remove('hidden')}
function renderCbTitle(){$('#channelBtn').textContent=`${t('KANAŁ')} ${state.channel}`;$('#channelValue').textContent=state.channel;$('#pttState').textContent=`${t('Kanał')} ${state.channel}`}
const HELP_TYPES={flat:{label:'Przebita opona',icon:'🛞',color:'#ff9500'},breakdown:{label:'Awaria pojazdu',icon:'🔧',color:'#00c7be'},fuel:{label:'Brak paliwa',icon:'⛽',color:'#ffd60a'},accident:{label:'Potrzebuję pomocy po zdarzeniu',icon:'🆘',color:'#ff3b30'},medical:{label:'Potrzebna pomoc medyczna',icon:'🏥',color:'#ff2d55'},other:{label:'Inna pomoc',icon:'🆘',color:'#8e44ff'}};
Object.entries(HELP_TYPES).forEach(([k,t])=>{REPORT_TYPES['help_'+k]={label:'Pomoc: '+t.label,icon:t.icon,color:t.color,priority:4}});
function openHelpModal(){const g=$('#helpGrid');g.innerHTML='';Object.entries(HELP_TYPES).forEach(([k,t])=>{const b=document.createElement('button');b.className='report-choice';b.style.setProperty('--report-color',t.color);b.innerHTML=`<span>${t.icon}</span><strong>${localizedHelpLabel(k)}</strong>`;b.onclick=()=>createHelp(k);g.appendChild(b)});$('#helpModal').classList.remove('hidden')}
async function createHelp(type){if(!state.userPos){try{await locate(true)}catch{showToast('Włącz GPS, aby wysłać wezwanie pomocy');return}}let p;try{p=await locate(true)}catch{showToast('Nie udało się pobrać aktualnej pozycji GPS');return}const now=Date.now(),h={id:uid(),type:'help_'+type,helpType:type,lat:p.coords.latitude,lon:p.coords.longitude,accuracy:Number.isFinite(p.coords.accuracy)?Math.round(p.coords.accuracy):null,createdAt:now,reportedAt:new Date(now).toISOString(),active:true,userId:getUserId()};state.helpRequests.unshift(h);$('#helpModal').classList.add('hidden');await post('/help',h);showToast(`${HELP_TYPES[type].icon} ${localizedHelpLabel(type)} — ${t('Powiadom kierowców w pobliżu')}`);speakText(`${t('Uwaga')}. ${t('Kierowca w pobliżu potrzebuje pomocy')}. ${localizedHelpLabel(type)}.`);renderHelpRequests();renderMap()}
async function getHelpRequests(){if(!apiBase()||!state.userPos)return;try{const q=new URLSearchParams({lat:state.userPos.lat,lon:state.userPos.lon,radius:10});const res=await fetch(apiBase()+'/help/nearby?'+q);if(res.ok){const d=await res.json();if(Array.isArray(d))state.helpRequests=d}}catch{}renderHelpRequests()}
function renderHelpRequests(){const box=$('#helpNearby');if(!box)return;const nearby=state.helpRequests.filter(h=>h.active!==false&&state.userPos&&distanceKm(state.userPos,{lat:h.lat,lon:h.lon})<=10);box.innerHTML=nearby.length?nearby.slice(0,5).map(h=>{const type=h.helpType||String(h.type||'').replace('help_','');const ht=HELP_TYPES[type]||HELP_TYPES.other;return `<button class="help-near-item" onclick="nav('map')"><span style="background:${ht.color}">${ht.icon}</span><div><b>${localizedHelpLabel(type)}</b><small>${formatDistance(h)} • ${ageText(h.createdAt)}</small></div></button>`}).join(''):`<div class="empty-state compact">${t('Brak wezwań pomocy w pobliżu.')}</div>`}
function speakText(text){if(!state.voiceAlerts)return;const n=nativeBridge();if(n?.available&&state.nativeAudio){try{n.speak(text,voiceLang(),state.alertVolume)}catch{}return}if(!('speechSynthesis'in window))return;try{speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(text);u.lang=voiceLang();u.rate=.92;u.volume=state.alertVolume;speechSynthesis.speak(u)}catch{}}
function renderLanguages(){
  const label=document.getElementById('languageText');
  if(label) label.textContent=LANGUAGES[state.language]||LANGUAGES.pl;
  const grid=document.getElementById('languageGrid');
  if(!grid)return;
  grid.innerHTML='';
  Object.entries(LANGUAGES).forEach(([code,labelText])=>{
    const b=document.createElement('button');
    b.type='button';
    b.className='language-choice'+(state.language===code?' selected':'');
    b.dataset.language=code;
    b.setAttribute('aria-pressed',state.language===code?'true':'false');
    b.textContent=labelText;
    b.addEventListener('click',e=>{
      e.preventDefault();
      e.stopPropagation();
      setLanguage(code);
    });
    grid.appendChild(b);
  });
}
function setLanguage(code){
  if(!LANGUAGES[code])return;
  state.language=code;
  persist();
  document.documentElement.lang=code;
  applyTranslations();
  renderLanguages();
  renderAll();
  renderSettingsSummary();
  closeLanguage();
  showToast(`${t('Język aplikacji:')} ${LANGUAGES[code]}`);
}
function openLanguage(){
  const m=document.getElementById('languageModal');
  if(!m)return;
  renderLanguages();
  m.classList.remove('hidden');
  m.setAttribute('aria-hidden','false');
  document.body.classList.add('language-open');
  document.body.style.overflow='hidden';
}
function closeLanguage(){
  const m=document.getElementById('languageModal');
  if(m){m.classList.add('hidden');m.setAttribute('aria-hidden','true');}
  document.body.classList.remove('language-open');
  document.body.style.overflow='';
}
window.AURIXOpenLanguage=openLanguage;
function bindLanguageUi(){
  const btn=document.getElementById('languageBtn');
  if(!btn)return;
  btn.type='button';
  btn.onclick=null;
  btn.removeAttribute('onclick');
  btn.setAttribute('aria-haspopup','dialog');
  btn.setAttribute('aria-controls','languageModal');
  btn.style.pointerEvents='auto';
  btn.style.touchAction='manipulation';
  // One handler only. No pointerup handler and no dynamic modal creation.
  btn.onclick=e=>{
    e.preventDefault();
    e.stopPropagation();
    openLanguage();
  };
  renderLanguages();
}

function openSettingsModal(id){
  // Only one settings dialog may be open at a time. The modal itself is a fixed top-level layer.
  ['soundSettings','reportSettings','distanceSettings','languageModal'].forEach(mid=>{const el=$('#'+mid);if(el&&mid!==id)el.classList.add('hidden')});
  if(id==='soundSettings')renderSoundSettings();
  if(id==='reportSettings')renderReportSettings();
  if(id==='distanceSettings')renderDistanceSettings();
  const m=$('#'+id);
  if(m){m.classList.remove('hidden');m.setAttribute('aria-hidden','false');document.body.classList.add('modal-open');}
}
function settingRow(label,sub,checked,onchange){const row=document.createElement('div');row.className='setting-row';row.innerHTML=`<div><b>${label}</b>${sub?`<small>${sub}</small>`:''}</div><button type="button" class="setting-toggle ${checked?'active':''}" aria-pressed="${checked}">${checked?'ON':'OFF'}</button>`;const b=row.querySelector('button');b.onclick=()=>{const v=!b.classList.contains('active');b.classList.toggle('active',v);b.textContent=v?'ON':'OFF';b.setAttribute('aria-pressed',v);onchange(v)};return row}
function renderSoundSettings(){const box=$('#soundSettingsBody');if(!box)return;box.innerHTML='';const s=accountSettings();const modes=[['standard','Standardowe','Pełne sygnały i komunikaty głosowe.'],['limited','Ograniczone','Komunikaty głosowe tylko bliżej zagrożenia.'],['warnings','Tylko ostrzeżenia','Tylko alerty o wyższym priorytecie.'],['off','Wyłącz','Bez dźwięków i komunikatów głosowych.']];const mode=document.createElement('div');mode.className='settings-choice-list';modes.forEach(([v,l,d])=>{const b=document.createElement('button');b.className='settings-choice '+(s.soundMode===v?'selected':'');b.innerHTML=`<span>🔊</span><div><b>${t(l)}</b><small>${t(d)}</small></div>${s.soundMode===v?'✓':''}`;b.onclick=()=>{state.soundMode=v;state.voiceAlerts=v!=='off'&&s.voiceEnabled;state.alertSoundEnabled=v!=='off';saveAccountSettings();renderSoundSettings()};mode.appendChild(b)});box.appendChild(mode);const voice=document.createElement('div');voice.className='settings-block';voice.innerHTML=`<label><b>${t('Aktualny głos')}</b><select id="voiceSelect"></select></label><label><b>${t('Głośność')}</b><input id="soundVolume" type="range" min="10" max="100" step="5" value="${Math.round(state.alertVolume*100)}"><strong id="soundVolumeValue">${Math.round(state.alertVolume*100)}%</strong></label>`;box.appendChild(voice);const vs=voice.querySelector('#voiceSelect');const fill=()=>{const voices=speechSynthesis?.getVoices?.()||[];vs.innerHTML='';voices.filter(v=>v.lang?.toLowerCase().startsWith(state.language)).forEach(v=>{const o=document.createElement('option');o.value=v.name;o.textContent=v.name;vs.appendChild(o)});if(!vs.options.length){const o=document.createElement('option');o.value='';o.textContent=t('Głos urządzenia');vs.appendChild(o)}vs.value=state.voiceName||vs.options[0]?.value||''};fill();if(speechSynthesis)speechSynthesis.onvoiceschanged=fill;vs.onchange=()=>{state.voiceName=vs.value;saveAccountSettings()};const vol=voice.querySelector('#soundVolume');vol.oninput=()=>{state.alertVolume=Number(vol.value)/100;voice.querySelector('#soundVolumeValue').textContent=vol.value+'%';saveAccountSettings()};box.appendChild(settingRow('🗣 '+t('Komunikaty głosowe'),t('Zależne od języka aplikacji.'),s.voiceEnabled,v=>{state.voiceAlerts=v;saveAccountSettings()}));box.appendChild(settingRow('🔔 '+t('Dźwięk alertów'),t('Sygnał przed komunikatem.'),s.alertSoundEnabled,v=>{state.alertSoundEnabled=v;saveAccountSettings()}))}
function renderReportSettings(){const box=$('#reportSettingsBody');if(!box)return;box.innerHTML='';const s=accountSettings();Object.keys(REPORT_TYPES).filter(k=>!k.startsWith('help_')).forEach(k=>{const row=document.createElement('div');row.className='report-setting-card';row.innerHTML=`<div class="report-setting-title"><span style="--c:${REPORT_TYPES[k].color}">${REPORT_TYPES[k].icon}</span><b>${localizedReportLabel(k)}</b></div><div class="report-setting-actions"></div>`;const a=row.querySelector('.report-setting-actions');a.appendChild(settingRow(t('Pokaż na mapie'),'',s.mapReports[k]!==false,v=>{state.localSettings=accountSettings();state.localSettings.mapReports[k]=v;saveAccountSettings()}));a.appendChild(settingRow(t('Ostrzegaj podczas jazdy'),'',s.driveAlerts[k]!==false,v=>{state.localSettings=accountSettings();state.localSettings.driveAlerts[k]=v;saveAccountSettings()}));box.appendChild(row)})}
function renderDistanceSettings(){const box=$('#distanceSettingsBody');if(!box)return;box.innerHTML='';const s=accountSettings();const current=normalizeAlertDistance(s.alertDistance);ALERT_DISTANCE_OPTIONS.forEach(([v,km,label])=>{const b=document.createElement('button');b.className='distance-choice '+(current===v?'selected':'');b.setAttribute('aria-pressed',current===v?'true':'false');b.innerHTML=`<span>${t(label)}</span>${current===v?'✓':''}`;b.onclick=()=>{state.alertDistance=v;state.localSettings=accountSettings();state.localSettings.alertDistance=v;saveAccountSettings();renderDistanceSettings();renderSettingsSummaries();state.alertStates.clear();state.alertDistanceHistory.clear();state.currentAlert=null;updateAlertEngine();renderLists();Promise.all([getReports(),getCameras()]).then(()=>{renderAll();updateAlertEngine()}).catch(()=>{});showToast(`${t('Odległość alertów')}: ${t(label)}`)};box.appendChild(b)})}
function renderSettingsSummary(){
 const hub=$('#accountSettingsHub'),basic=$('#basicSoundControls');
 if(hub)hub.classList.remove('hidden');
 if(basic)basic.classList.remove('hidden');
 const s=accountSettings();
 const sm=$('#soundSummary'),dm=$('#distanceSummary');
 if(sm)sm.textContent=t(s.soundMode==='standard'?'Standardowe':s.soundMode==='limited'?'Ograniczone':s.soundMode==='warnings'?'Tylko ostrzeżenia':'Wyłącz');
 if(dm){const key=normalizeAlertDistance(s.alertDistance);const found=ALERT_DISTANCE_OPTIONS.find(x=>x[0]===key);dm.textContent=t(found?found[2]:'5 km');}
}
async function sendPresence(){
 if(!apiBase()||!state.userPos||!state.cbOnline)return;
 try{
  const result=await post('/presence',{deviceId:getUserId(),lat:state.userPos.lat,lon:state.userPos.lon,range:state.range,channel:state.channel,online:true,mode:state.driving?'driving':'cb'});
  if(result?.ok){state.onlineUsers=Number(result.data?.count)||0;state.onlinePresenceReady=true;renderOnlineUsers();}
 }catch{state.onlinePresenceReady=false;state.onlineUsers=0;renderOnlineUsers()}
}
async function leaveCbOnline(){
 state.cbOnline=false;
 try{if(apiBase())await post('/presence',{deviceId:getUserId(),online:false});}catch{}
 closeCbRealtime();
 state.onlineUsers=0;state.onlinePresenceReady=true;renderOnlineUsers();
 renderCbOnlineButton();
}
async function enterCbOnline(){
 if(!state.userPos){try{await locate();}catch{showToast('AURIX potrzebuje lokalizacji, aby włączyć CB');return}}
 state.cbOnline=true;
 renderCbOnlineButton();
 await sendPresence();
 connectCbRealtime();
 showToast('CB: ONLINE');
}
function renderCbOnlineButton(){
 const b=$('#cbOnlineToggle'); if(!b)return;
 b.classList.toggle('is-online',!!state.cbOnline);
 b.classList.toggle('is-offline',!state.cbOnline);
 b.setAttribute('aria-pressed',String(!!state.cbOnline));
 const label=b.querySelector('[data-cb-status]'); if(label)label.textContent=state.cbOnline?'ONLINE':'OFFLINE';
}
async function toggleCbOnline(){ if(state.cbOnline)await leaveCbOnline();else await enterCbOnline(); }
async function setupOnlinePresence(){ renderCbOnlineButton(); }
function renderOnlineUsers(){
 const value=state.cbOnline&&state.onlinePresenceReady?String(Math.max(0,state.onlineUsers)):'0';
 const el=$('#onlineUsersCount'); if(el)el.textContent=value;
 const home=$('#homeOnlineCount'); if(home)home.textContent=value;
 const drive=$('#driveOnline'); if(drive)drive.textContent=value;
}
async function updateOnlinePresenceMode(){ if(state.cbOnline)await sendPresence(); }

function cbSend(msg){try{if(state.cbSocket&&state.cbSocket.readyState===1)state.cbSocket.send(JSON.stringify(msg));}catch{}}
function closeCbRealtime(){
 for(const [id,pc] of state.cbPeers){try{pc.onicecandidate=null;pc.ontrack=null;pc.close();}catch{} }
 state.cbPeers.clear();
 if(state.cbSocket){try{state.cbSocket.close();}catch{}state.cbSocket=null;}
 for(const a of state.cbAudioEls.values()){try{a.pause();a.srcObject=null;a.remove();}catch{}}
 state.cbAudioEls.clear();
}
async function getCbStream(){
 if(state.cbStream)return state.cbStream;
 if(!navigator.mediaDevices?.getUserMedia)throw new Error('Mikrofon nie jest dostępny');
 state.cbStream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true}});
 state.cbStream.getAudioTracks().forEach(t=>t.enabled=false);
 return state.cbStream;
}
function attachCbTracks(pc){
 if(!state.cbStream)return;
 const senders=pc.getSenders().filter(s=>s.track);
 for(const track of state.cbStream.getAudioTracks()) if(!senders.some(s=>s.track?.id===track.id)) pc.addTrack(track,state.cbStream);
}
function addCbPeer(peerId,initiator=false){
 if(!peerId||peerId===getUserId()||state.cbPeers.has(peerId))return state.cbPeers.get(peerId);
 const pc=new RTCPeerConnection({iceServers:[{urls:'stun:stun.l.google.com:19302'}]});
 state.cbPeers.set(peerId,pc);attachCbTracks(pc);
 pc.onicecandidate=e=>{if(e.candidate)cbSend({type:'signal',to:peerId,data:{candidate:e.candidate}})};
 pc.ontrack=e=>{let a=state.cbAudioEls.get(peerId);if(!a){a=document.createElement('audio');a.autoplay=true;a.playsInline=true;a.dataset.peerId=peerId;a.style.display='none';document.body.appendChild(a);state.cbAudioEls.set(peerId,a);}a.srcObject=e.streams[0];if(state.listen)a.play().catch(()=>{});};
 pc.onconnectionstatechange=()=>{if(['failed','closed','disconnected'].includes(pc.connectionState)){try{pc.close()}catch{}state.cbPeers.delete(peerId);}};
 if(initiator)pc.createOffer().then(o=>pc.setLocalDescription(o)).then(()=>cbSend({type:'signal',to:peerId,data:{description:pc.localDescription}})).catch(()=>{});
 return pc;
}
async function handleCbSignal(from,data){
 const pc=addCbPeer(from,false); if(!pc)return;
 try{
  if(data.description?.type==='offer'){
   await pc.setRemoteDescription(data.description);attachCbTracks(pc);const ans=await pc.createAnswer();await pc.setLocalDescription(ans);cbSend({type:'signal',to:from,data:{description:pc.localDescription}});
  }else if(data.description?.type==='answer'){
   await pc.setRemoteDescription(data.description);
  }else if(data.candidate){await pc.addIceCandidate(data.candidate).catch(()=>{});
  }
 }catch(e){console.warn('[AURIX] CB signaling',e)}
}
function connectCbRealtime(){
 if(!state.cbOnline||!apiBase()||!state.userPos||!window.RTCPeerConnection)return;
 if(state.cbSocket&&state.cbSocket.readyState===1){cbSend({type:'presence',deviceId:getUserId(),lat:state.userPos.lat,lon:state.userPos.lon,channel:state.channel,range:state.range});return;}
 closeCbRealtime();
 const url=wsBase(); if(!/^wss?:\/\//.test(url))return;
 try{
  const ws=new WebSocket(url);state.cbSocket=ws;
  ws.onopen=()=>cbSend({type:'presence',deviceId:getUserId(),lat:state.userPos.lat,lon:state.userPos.lon,channel:state.channel,range:state.range});
  ws.onmessage=e=>{try{const m=JSON.parse(e.data);if(m.type==='peers'){for(const id of m.peers||[])if(getUserId()<id)addCbPeer(id,true);}else if(m.type==='peer_join'){if(getUserId()<m.peerId)addCbPeer(m.peerId,true);}else if(m.type==='signal'){handleCbSignal(m.from,m.data);}else if(m.type==='peer_leave'){const pc=state.cbPeers.get(m.peerId);if(pc)try{pc.close()}catch{}state.cbPeers.delete(m.peerId);const a=state.cbAudioEls.get(m.peerId);if(a){try{a.remove()}catch{}state.cbAudioEls.delete(m.peerId)}}}catch{}};
  ws.onclose=()=>{if(state.cbSocket===ws)state.cbSocket=null;};
 }catch{state.cbSocket=null;}
}
async function startCbTalk(){
 if(!state.cbOnline){showToast('Najpierw włącz CB: ONLINE');throw new Error('offline')}
 try{await getCbStream();connectCbRealtime();const track=state.cbStream.getAudioTracks()[0];track.enabled=true;for(const pc of state.cbPeers.values())attachCbTracks(pc);showToast('Nadawanie CB aktywne');}catch{showToast('Aby nadawać, zezwól na mikrofon');throw new Error('mic')}
}
function stopCbTalk(){if(state.cbStream)state.cbStream.getAudioTracks().forEach(t=>t.enabled=false);}

function forceCloseOnboarding(){
 const onboarding=document.getElementById('onboarding');
 if(!onboarding)return;
 onboarding.classList.add('hidden');
 onboarding.setAttribute('aria-hidden','true');
 onboarding.setAttribute('aria-modal','false');
 onboarding.style.display='none';
 onboarding.style.pointerEvents='none';
 onboarding.style.visibility='hidden';
 document.body.classList.remove('onboarding-open');
 document.body.style.overflow='';
}
window.AURIXSkipGps=()=>{localStorage.setItem('aurixOnboarded','1');forceCloseOnboarding();};
window.AURIXAllowGps=()=>{const b=document.getElementById('allowGps');if(b)b.click();};
function setGpsStatus(message){
 const el=$('#gpsStatus');
 if(el){
  const b=el.querySelector('b');
  if(b)b.textContent=message;
  else el.textContent=message;
  el.setAttribute('aria-label',message);
 }
}
function bindOnboardingControls(){
 const onboarding=document.getElementById('onboarding');
 const allow=document.getElementById('allowGps');
 const skip=document.getElementById('skipGps');
 if(!onboarding)return;
 if(skip){
  skip.type='button';
  skip.onclick=(e)=>{e.preventDefault();e.stopPropagation();window.AURIXSkipGps();};
 }
 if(allow){
  allow.type='button';
  allow.onclick=async(e)=>{
   e.preventDefault();e.stopPropagation();
   if(allow.disabled)return;
   if(!window.isSecureContext){showToast('GPS wymaga bezpiecznego połączenia HTTPS.');return;}
   if(!navigator.geolocation){showToast('Ta przeglądarka nie obsługuje lokalizacji.');return;}
   const original=allow.textContent;
   allow.disabled=true;allow.setAttribute('aria-busy','true');allow.textContent='POBIERAM LOKALIZACJĘ…';
   try{
    await locate(true);
    localStorage.setItem('aurixOnboarded','1');
    forceCloseOnboarding();
    setGpsStatus('GPS: WŁ.');
    watchGps();
    renderAll();
    showToast('Lokalizacja włączona');
   }catch(err){
    allow.disabled=false;allow.removeAttribute('aria-busy');allow.textContent=original;
    // locate() already gives the user the precise error. Keep the modal usable.
   }
  };
 }
}
function safeBind(selector,event,handler){const el=$(selector);if(!el)return null;el.addEventListener(event,handler);return el;}
function init(){
 bindOnboardingControls();
 try{load();}catch(e){console.error('[AURIX] load failed',e);}
 const safe=(label,fn)=>{try{return fn();}catch(e){console.error('[AURIX] '+label+' failed',e);return null;}};
 safe('renderReportButtons',renderReportButtons);
 safe('renderFilters',renderFilters);
 safe('initMap',initMap);
 if(localStorage.getItem('aurixOnboarded'))safe('watchGps',watchGps);
 safe('renderAll',renderAll);
 safe('renderSettingsSummary',renderSettingsSummary);
 safe('setupNativeSettings',setupNativeSettings);
 $$('[data-nav]').forEach(b=>b.onclick=()=>nav(b.dataset.nav));
 safeBind('#startDrive','click',startDrive);
 safeBind('#stopDrive','click',stopDrive);
 safeBind('#reportOpen','click',()=>$('#reportModal')?.classList.remove('hidden'));
 $$('[data-close]').forEach(b=>b.onclick=()=>{const id=b.dataset.close;if(id==='languageModal')closeLanguage();else $('#'+id)?.classList.add('hidden')});
 safeBind('#locateBtn','click',()=>locate(true).catch(()=>{}));
 safeBind('#gpsStatus','click',()=>locate(true).catch(()=>{}));
 safeBind('#gpsPermission','click',()=>locate(true).catch(()=>{}));
 safeBind('#notificationPermission','click',requestNotifications);
 safeBind('#voicePermission','click',requestMic);
 const av=$('#alertVolume');
 if(av){av.value=Math.round(state.alertVolume*100);if($('#alertVolumeValue'))$('#alertVolumeValue').textContent=av.value+'%';av.oninput=e=>{state.alertVolume=Number(e.target.value)/100;if($('#alertVolumeValue'))$('#alertVolumeValue').textContent=e.target.value+'%';persist();playAlertSound(1);};}
 safeBind('#voiceAlertsToggle','click',e=>{state.voiceAlerts=!state.voiceAlerts;e.currentTarget.classList.toggle('active',state.voiceAlerts);const b=e.currentTarget.querySelector('b');if(b)b.textContent=state.voiceAlerts?'ON':'OFF';persist();});
 if(!state.voiceAlerts)$('#voiceAlertsToggle')?.classList.remove('active');
 safeBind('#refreshBtn','click',async()=>{try{await getReports();await getCameras();await getCbPresence();await getHelpRequests();renderAll();showToast('Dane odświeżone')}catch(e){console.error(e);showToast('Nie udało się odświeżyć danych')}});
 const rs=$('#rangeSlider');if(rs){rs.value=state.range;if($('#rangeValue'))$('#rangeValue').textContent=state.range+' km';rs.oninput=e=>{state.range=Number(e.target.value);if($('#rangeValue'))$('#rangeValue').textContent=state.range+' km';persist();updateCounts();};}
 safeBind('#listenToggle','click',e=>{state.listen=!state.listen;e.currentTarget.classList.toggle('active',state.listen);const b=e.currentTarget.querySelector('b');if(b)b.textContent=state.listen?'ON':'OFF';for(const a of state.cbAudioEls.values()){a.muted=!state.listen;if(state.listen)a.play().catch(()=>{})}persist();});
 safeBind('#directionToggle','click',e=>{state.directionOnly=!state.directionOnly;e.currentTarget.classList.toggle('active',state.directionOnly);const b=e.currentTarget.querySelector('b');if(b)b.textContent=state.directionOnly?'ON':'OFF';persist();});
 if(!state.listen)$('#listenToggle')?.classList.remove('active');$('#directionToggle')?.classList.toggle('active',state.directionOnly);
 safe('setupPTT',setupPTT); safeBind('#cbOnlineToggle','click',toggleCbOnline); renderCbOnlineButton();
 safeBind('#channelBtn','click',openChannelModal);
 safe('bindLanguageUi',bindLanguageUi);
 safeBind('#soundSettingsBtn','click',()=>openSettingsModal('soundSettings'));
 safeBind('#reportSettingsBtn','click',()=>openSettingsModal('reportSettings'));
 safeBind('#distanceSettingsBtn','click',()=>openSettingsModal('distanceSettings'));
 $$('[data-settings-close]').forEach(b=>b.onclick=()=>{
  const el=$('#'+b.dataset.settingsClose);
  if(el){el.classList.add('hidden');el.setAttribute('aria-hidden','true');}
  if(!$$('.modal:not(.hidden)').length)document.body.classList.remove('modal-open');
});
 safeBind('#helpOpen','click',openHelpModal);
 safeBind('#helpOpenDrive','click',openHelpModal);
 safe('applyTranslations',applyTranslations);
 safeBind('#privacyBtn','click',()=>showToast('Prywatność: dane lokalizacyjne są używane tylko do funkcji drogowych'));
 if(localStorage.getItem('aurixOnboarded'))forceCloseOnboarding();else document.body.classList.add('onboarding-open');
 safe('renderLanguages',renderLanguages);
 setTimeout(()=>safe('setupOnlinePresence',setupOnlinePresence),800);
 // Initial network sync: obtain a fresh position as soon as the app opens, then
 // immediately load current reports/help/cameras/CB presence. Do not wait for
 // the user to open the Alerts screen or press the manual refresh button.
 if(localStorage.getItem('aurixOnboarded')){
   setTimeout(async()=>{
     try{
       if(!state.userPos) await locate(true);
       else await refreshNetworkData(true);
     }catch(e){
       // GPS permission/availability errors are already surfaced by locate().
       // Keep the app usable; the GPS watcher and visibility handler will retry.
     }
   },150);
 }
 if('serviceWorker' in navigator){navigator.serviceWorker.register('./sw.js',{updateViaCache:'none'}).then(r=>r.update()).catch(e=>console.warn('[AURIX] service worker',e));}
}
function renderAll(){renderLists();renderFilters();renderMap();updateCounts()}
document.addEventListener('DOMContentLoaded',init);
document.addEventListener('visibilitychange',()=>{if(!document.hidden){const n=nativeBridge();if(n?.available){try{const p=n.permissions();state.nativeBackgroundGps=p?.backgroundLocation==='granted';state.nativeNotifications=p?.notifications==='granted';updateNativeSettingsUI()}catch{}}syncNativeLocation();refreshNetworkData(true);if(state.driving)updateAlertEngine()}});
setInterval(()=>{if(state.userPos)refreshNetworkData();if(state.driving)updateAlertEngine();if(state.userPos&&state.cbOnline){sendPresence();if(state.cbSocket)cbSend({type:'presence',deviceId:getUserId(),lat:state.userPos.lat,lon:state.userPos.lon,channel:state.channel,range:state.range,online:true});}renderLists()},7000);

// Global UI hardening: prevent long-press text selection/callouts on non-editable AURIX UI.
(function installTextSelectionGuard(){
  const isEditable = (el) => {
    if (!el || !(el instanceof Element)) return false;
    return !!el.closest('input, textarea, select, option, [contenteditable="true"], [contenteditable="plaintext-only"]');
  };

  document.addEventListener('selectstart', (e) => {
    if (!isEditable(e.target)) e.preventDefault();
  }, {passive:false});

  document.addEventListener('dragstart', (e) => {
    if (!isEditable(e.target)) e.preventDefault();
  }, {passive:false});

  document.addEventListener('contextmenu', (e) => {
    // Keep the native context menu for editable controls; suppress it on the app UI.
    if (!isEditable(e.target)) e.preventDefault();
  });
})();
