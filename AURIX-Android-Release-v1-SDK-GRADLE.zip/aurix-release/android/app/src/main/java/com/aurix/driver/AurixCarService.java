package com.aurix.driver;

import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.SharedPreferences;

import androidx.annotation.NonNull;
import androidx.car.app.CarAppService;
import androidx.car.app.CarContext;
import androidx.car.app.Screen;
import androidx.car.app.Session;
import androidx.car.app.model.Action;
import androidx.car.app.model.Pane;
import androidx.car.app.model.PaneTemplate;
import androidx.car.app.model.Row;
import androidx.car.app.model.Template;
import androidx.car.app.validation.HostValidator;

public class AurixCarService extends CarAppService {
    @Override public Session onCreateSession() { return new AurixCarSession(); }

    @Override public HostValidator createHostValidator() {
        if ((getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0) return HostValidator.ALLOW_ALL_HOSTS_VALIDATOR;
        return new HostValidator.Builder(getApplicationContext())
                .addAllowedHosts(androidx.car.app.R.array.hosts_allowlist_sample)
                .build();
    }
}

class AurixCarSession extends Session {
    @NonNull @Override public Screen onCreateScreen(@NonNull Intent intent) { return new AurixCarScreen(getCarContext()); }
}

class AurixCarScreen extends Screen {
    AurixCarScreen(@NonNull CarContext carContext) { super(carContext); }

    @NonNull @Override public Template onGetTemplate() {
        SharedPreferences p = getCarContext().getSharedPreferences("aurix_native", CarContext.MODE_PRIVATE);
        String alert = p.getString("currentAlertLabel", "");
        float distance = p.getFloat("currentAlertDistance", 0f);
        boolean driving = p.getBoolean("driving", false);
        String location = p.getString("lastLocation", "{}");

        Pane.Builder pane = new Pane.Builder();
        if (!alert.isEmpty()) {
            String d = distance >= 1000f ? String.format(java.util.Locale.US, "%.1f km", distance / 1000f) : Math.round(distance) + " m";
            pane.addRow(new Row.Builder().setTitle("ALERT PRZED TOBĄ").addText(alert + " • " + d).build());
        } else {
            pane.addRow(new Row.Builder().setTitle("Brak aktywnego alertu").addText(driving ? "AURIX monitoruje drogę" : "Uruchom tryb jazdy w telefonie").build());
        }
        pane.addRow(new Row.Builder().setTitle("GPS").addText(location.equals("{}") ? "Brak pozycji" : "Pozycja aktywna").build());
        return new PaneTemplate.Builder(pane.build())
                .setTitle("AURIX")
                .setHeaderAction(Action.APP_ICON)
                .build();
    }
}
