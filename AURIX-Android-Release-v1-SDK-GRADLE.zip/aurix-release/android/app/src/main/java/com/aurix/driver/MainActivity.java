package com.aurix.driver;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.getcapacitor.BridgeActivity;

import org.json.JSONObject;

import java.util.Locale;

public class MainActivity extends BridgeActivity {
    private static final int REQUEST_PERMISSIONS = 7001;
    private static MainActivity instance;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;
    private android.speech.tts.TextToSpeech tts;

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        instance = this;
        prefs = getSharedPreferences("aurix_native", MODE_PRIVATE);
        WebView webView = getBridge().getWebView();
        webView.getSettings().setJavaScriptEnabled(true);
        webView.addJavascriptInterface(new NativeBridge(this), "AURIXNative");
        tts = new android.speech.tts.TextToSpeech(this, status -> { });
        if (prefs.getBoolean("autoStartGps", false)) {
            handler.postDelayed(() -> startLocationService(), 1200);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        pushLocationToWeb();
    }

    @Override
    protected void onDestroy() {
        if (instance == this) instance = null;
        if (tts != null) tts.shutdown();
        super.onDestroy();
    }

    private boolean granted(String permission) {
        return ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestAppPermissions() {
        java.util.ArrayList<String> list = new java.util.ArrayList<>();
        if (!granted(Manifest.permission.ACCESS_FINE_LOCATION) && !granted(Manifest.permission.ACCESS_COARSE_LOCATION)) {
            list.add(Manifest.permission.ACCESS_FINE_LOCATION);
            list.add(Manifest.permission.ACCESS_COARSE_LOCATION);
        }
        if (Build.VERSION.SDK_INT >= 33 && !granted(Manifest.permission.POST_NOTIFICATIONS)) list.add(Manifest.permission.POST_NOTIFICATIONS);
        if (!granted(Manifest.permission.RECORD_AUDIO)) list.add(Manifest.permission.RECORD_AUDIO);
        if (!list.isEmpty()) ActivityCompat.requestPermissions(this, list.toArray(new String[0]), REQUEST_PERMISSIONS);
        else startLocationServiceIfAllowed();
    }

    private void requestBackgroundLocation() {
        if (Build.VERSION.SDK_INT < 29) { startLocationService(); return; }
        if (!granted(Manifest.permission.ACCESS_FINE_LOCATION) && !granted(Manifest.permission.ACCESS_COARSE_LOCATION)) {
            requestAppPermissions();
            return;
        }
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } catch (Exception ignored) { }
        } else if (!granted(Manifest.permission.ACCESS_BACKGROUND_LOCATION)) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_BACKGROUND_LOCATION}, REQUEST_PERMISSIONS + 1);
        }
    }

    private void startLocationServiceIfAllowed() {
        if (granted(Manifest.permission.ACCESS_FINE_LOCATION) || granted(Manifest.permission.ACCESS_COARSE_LOCATION)) startLocationService();
    }

    public void startLocationService() {
        if (!(granted(Manifest.permission.ACCESS_FINE_LOCATION) || granted(Manifest.permission.ACCESS_COARSE_LOCATION))) return;
        try {
            Intent i = new Intent(this, AurixLocationService.class);
            ContextCompat.startForegroundService(this, i);
        } catch (Exception ignored) { }
    }

    public void stopLocationService() {
        try { stopService(new Intent(this, AurixLocationService.class)); } catch (Exception ignored) { }
    }

    public void keepScreenOn(boolean enabled) {
        runOnUiThread(() -> {
            if (enabled) getWindow().addFlags(WindowManagerFlags.FLAG_KEEP_SCREEN_ON);
            else getWindow().clearFlags(WindowManagerFlags.FLAG_KEEP_SCREEN_ON);
        });
    }

    private static class WindowManagerFlags {
        static final int FLAG_KEEP_SCREEN_ON = android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON;
    }

    public void playNativeAlert(int level, float volume, float distance) {
        int vol = Math.max(1, Math.min(100, Math.round(volume * 100f)));
        ToneGenerator tone = new ToneGenerator(AudioManager.STREAM_NOTIFICATION, vol);
        tone.startTone(ToneGenerator.TONE_PROP_BEEP, 100);
        if (distance <= 100f) {
            handler.postDelayed(() -> {
                try { tone.startTone(ToneGenerator.TONE_PROP_BEEP, 100); } catch (Exception ignored) { }
                handler.postDelayed(tone::release, 140);
            }, 115);
        } else {
            handler.postDelayed(tone::release, 140);
        }
    }

    public void speakNative(String text, String language, float volume) {
        if (tts == null || text == null || text.isEmpty()) return;
        runOnUiThread(() -> {
            try {
                Locale locale = Locale.forLanguageTag(language == null || language.isEmpty() ? "pl" : language);
                tts.setLanguage(locale);
                tts.setSpeechRate(.92f);
                tts.setPitch(1f);
                if (Build.VERSION.SDK_INT >= 21) tts.speak(text, android.speech.tts.TextToSpeech.QUEUE_FLUSH, null, "aurix-alert");
                else tts.speak(text, android.speech.tts.TextToSpeech.QUEUE_FLUSH, null);
            } catch (Exception ignored) { }
        });
    }

    public void vibrate(String kind) {
        android.os.Vibrator v = (android.os.Vibrator) getSystemService(VIBRATOR_SERVICE);
        if (v == null || !v.hasVibrator()) return;
        if (Build.VERSION.SDK_INT >= 26) {
            long[] pattern = "alert".equals(kind) ? new long[]{0,60,70,60} : new long[]{0,70};
            v.vibrate(android.os.VibrationEffect.createWaveform(pattern, -1));
        } else {
            v.vibrate("alert".equals(kind) ? new long[]{0,60,70,60} : new long[]{0,70}, -1);
        }
    }

    public String permissionStatus() {
        JSONObject o = new JSONObject();
        try {
            o.put("fineLocation", granted(Manifest.permission.ACCESS_FINE_LOCATION) ? "granted" : "denied");
            o.put("coarseLocation", granted(Manifest.permission.ACCESS_COARSE_LOCATION) ? "granted" : "denied");
            o.put("backgroundLocation", Build.VERSION.SDK_INT < 29 || granted(Manifest.permission.ACCESS_BACKGROUND_LOCATION) ? "granted" : "denied");
            o.put("notifications", Build.VERSION.SDK_INT < 33 || granted(Manifest.permission.POST_NOTIFICATIONS) ? "granted" : "denied");
            o.put("microphone", granted(Manifest.permission.RECORD_AUDIO) ? "granted" : "denied");
            o.put("batteryOptimizationIgnored", isIgnoringBatteryOptimizations());
        } catch (Exception ignored) { }
        return o.toString();
    }

    public boolean isIgnoringBatteryOptimizations() {
        if (Build.VERSION.SDK_INT < 23) return true;
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        return pm != null && pm.isIgnoringBatteryOptimizations(getPackageName());
    }

    public void openBatterySettings() {
        try {
            Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName()));
            startActivity(i);
        } catch (Exception ignored) { openAppSettings(); }
    }

    public void openAppSettings() {
        try { startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()))); } catch (Exception ignored) { }
    }

    public void setCurrentAlert(String label, double distance, int priority) {
        prefs.edit().putString("currentAlertLabel", label).putFloat("currentAlertDistance", (float) distance).putInt("currentAlertPriority", priority).apply();
    }

    public void postAlertNotification(String label, String distance) {
        AurixLocationService.postAlertNotification(this, label, distance);
    }

    public void setDriveState(boolean driving) { prefs.edit().putBoolean("driving", driving).apply(); }

    public String getLastLocation() { return prefs.getString("lastLocation", "{}"); }

    private void pushLocationToWeb() {
        String json = getLastLocation();
        try {
            String js = "window.AURIXNativeLocation&&window.AURIXNativeLocation(" + JSONObject.quote(json) + ");";
            getBridge().getWebView().post(() -> getBridge().getWebView().evaluateJavascript(js, null));
        } catch (Exception ignored) { }
    }

    public static void pushLocation(double lat, double lon, float accuracy, float speed, float bearing) {
        MainActivity a = instance;
        if (a == null) return;
        JSONObject o = new JSONObject();
        try {
            o.put("lat", lat); o.put("lon", lon); o.put("accuracy", accuracy); o.put("speed", speed); o.put("heading", bearing); o.put("timestamp", System.currentTimeMillis());
        } catch (Exception ignored) { }
        String json = o.toString();
        a.prefs.edit().putString("lastLocation", json).apply();
        try {
            String js = "window.AURIXNativeLocation&&window.AURIXNativeLocation(" + JSONObject.quote(json) + ");";
            a.getBridge().getWebView().post(() -> a.getBridge().getWebView().evaluateJavascript(js, null));
        } catch (Exception ignored) { }
    }

    public class NativeBridge {
        private final MainActivity a;
        NativeBridge(MainActivity activity) { a = activity; }
        @JavascriptInterface public String getPermissionStatus(){ return a.permissionStatus(); }
        @JavascriptInterface public void requestPermissions(){ a.requestAppPermissions(); }
        @JavascriptInterface public void requestBackgroundLocation(){ a.requestBackgroundLocation(); }
        @JavascriptInterface public void startBackgroundLocation(){ a.startLocationService(); }
        @JavascriptInterface public void stopBackgroundLocation(){ a.stopLocationService(); }
        @JavascriptInterface public void setKeepScreenOn(boolean enabled){ a.keepScreenOn(enabled); }
        @JavascriptInterface public void playAlert(int level,float volume,float distance){ a.playNativeAlert(level,volume,distance); }
        @JavascriptInterface public void speak(String text,String lang,float volume){ a.speakNative(text,lang,volume); }
        @JavascriptInterface public void vibrate(String kind){ a.vibrate(kind); }
        @JavascriptInterface public void setAutoStart(boolean enabled){ a.prefs.edit().putBoolean("autoStartGps",enabled).apply(); if(enabled)a.startLocationService(); else if(!a.prefs.getBoolean("driving",false))a.stopLocationService(); }
        @JavascriptInterface public boolean getAutoStart(){ return a.prefs.getBoolean("autoStartGps",false); }
        @JavascriptInterface public String getLastLocation(){ return a.getLastLocation(); }
        @JavascriptInterface public void setDriveState(boolean driving){ a.setDriveState(driving); }
        @JavascriptInterface public void setCurrentAlert(String label,double distance,int priority){ a.setCurrentAlert(label,distance,priority); }
        @JavascriptInterface public void postAlertNotification(String label,String distance){ a.postAlertNotification(label,distance); }
        @JavascriptInterface public void openAppSettings(){ a.openAppSettings(); }
        @JavascriptInterface public void openBatterySettings(){ a.openBatterySettings(); }
        @JavascriptInterface public boolean isIgnoringBatteryOptimizations(){ return a.isIgnoringBatteryOptimizations(); }
        @JavascriptInterface public void openAndroidAuto(){ a.showToastNative("Android Auto: AURIX jest przygotowany do warstwy samochodowej."); }
    }

    private void showToastNative(String text) {
        android.widget.Toast.makeText(this, text, android.widget.Toast.LENGTH_SHORT).show();
    }
}
