package com.aurix.driver;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Build;
import android.os.IBinder;

import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.ServiceCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.Priority;

public class AurixLocationService extends Service {
    public static final String CHANNEL_ID = "aurix_driver";
    public static final String ALERT_CHANNEL_ID = "aurix_alerts";
    private static final int FOREGROUND_ID = 4101;
    private static final int ALERT_ID = 4102;
    private FusedLocationProviderClient locationClient;
    private LocationCallback callback;

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        locationClient = LocationServices.getFusedLocationProviderClient(this);
        callback = new LocationCallback() {
            @Override public void onLocationResult(LocationResult result) {
                if (result == null) return;
                Location l = result.getLastLocation();
                if (l == null) return;
                MainActivity.pushLocation(l.getLatitude(), l.getLongitude(), l.hasAccuracy()?l.getAccuracy():50f,
                        l.hasSpeed()?l.getSpeed():0f, l.hasBearing()?l.getBearing():-1f);
            }
        };
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        startAsForeground();
        requestUpdates();
        return START_STICKY;
    }

    private void startAsForeground() {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 1, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification n = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                .setContentTitle("AURIX")
                .setContentText("GPS i alerty działają w tle")
                .setOngoing(true)
                .setCategory(NotificationCompat.CATEGORY_SERVICE)
                .setContentIntent(pi)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build();
        if (Build.VERSION.SDK_INT >= 29) {
            ServiceCompat.startForeground(this, FOREGROUND_ID, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION);
        } else {
            startForeground(FOREGROUND_ID, n);
        }
    }

    private void requestUpdates() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) return;
        LocationRequest request = new LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 2000L)
                .setMinUpdateIntervalMillis(1000L)
                .setMaxUpdateDelayMillis(4000L)
                .setWaitForAccurateLocation(false)
                .build();
        try { locationClient.requestLocationUpdates(request, callback, getMainLooper()); } catch (SecurityException ignored) { }
    }

    public static void postAlertNotification(Context context, String label, String distance) {
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        if (Build.VERSION.SDK_INT >= 33 && ActivityCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return;
        Intent open = new Intent(context, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(context, 2, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification n = new NotificationCompat.Builder(context, ALERT_CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle("AURIX • " + label)
                .setContentText(distance)
                .setAutoCancel(true)
                .setCategory(NotificationCompat.CATEGORY_NAVIGATION)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(pi)
                .build();
        nm.notify(ALERT_ID, n);
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL_ID, "AURIX GPS w tle", NotificationManager.IMPORTANCE_LOW);
            c.setDescription("Stała informacja o działaniu GPS AURIX");
            c.setSound(null, null);
            NotificationChannel a = new NotificationChannel(ALERT_CHANNEL_ID, "AURIX alerty", NotificationManager.IMPORTANCE_HIGH);
            a.setDescription("Pilne ostrzeżenia drogowe AURIX");
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) { nm.createNotificationChannel(c); nm.createNotificationChannel(a); }
        }
    }

    @Override public void onDestroy() {
        if (locationClient != null && callback != null) locationClient.removeLocationUpdates(callback);
        super.onDestroy();
    }

    @Nullable @Override public IBinder onBind(Intent intent) { return null; }
}
