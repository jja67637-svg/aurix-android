# AURIX Android — wersja natywna

Projekt wykorzystuje Capacitor jako natywny kontener Android, ale funkcje wymagające ciągłego działania są zaimplementowane bezpośrednio w Javie.

## Funkcje

- natywny foreground service GPS, także przy wygaszonym ekranie,
- systemowe powiadomienia Android,
- natywne TTS i sygnały audio alertów,
- wibracje alertów,
- utrzymanie ekranu podczas jazdy,
- obsługa uprawnień lokalizacji/mikrofonu/powiadomień,
- opcjonalny start GPS przy uruchomieniu aplikacji,
- odbiornik startu urządzenia dla wcześniej włączonego auto-startu,
- warstwa Android Auto oparta o Android for Cars / Car App Library (kategoria POI),
- synchronizacja ostatniej pozycji z interfejsem webowym.

## Budowanie

1. Zainstaluj Android Studio oraz Android SDK API 36.
2. Otwórz katalog `android/` w Android Studio.
3. Upewnij się, że Gradle używa 8.14.3 i JDK 21.
4. Wykonaj Gradle Sync. Zależności są pobierane z Google Maven/Maven Central.
5. Uruchom wariant `debug` na telefonie Android.
6. Do publikacji utwórz podpisany AAB w Android Studio.

Jeśli chcesz używać Capacitor CLI do synchronizacji po zmianach webowych, najpierw wykonaj `npm install`, a następnie `npx cap sync android`.

## Ważne ograniczenie Androida

Android nakłada ograniczenia na uruchamianie usług lokalizacyjnych z tła. AURIX uruchamia usługę lokalizacji po widocznej akcji użytkownika, a start po restarcie urządzenia jest wykonywany tylko wtedy, gdy użytkownik wcześniej włączył auto-start i systemowe wymagania lokalizacji w tle są spełnione. Android 14+ wymaga zadeklarowania typu `location` oraz `FOREGROUND_SERVICE_LOCATION`.

Android Auto jest przygotowany jako osobna, kierowco-zoptymalizowana warstwa Car App. AURIX nie deklaruje się jako nawigacja turn-by-turn, ponieważ obecny produkt jest aplikacją alertów drogowych, a nie nawigacją.
