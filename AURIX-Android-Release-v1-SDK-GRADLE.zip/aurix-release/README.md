# AURIX — European Driver Network

AURIX to aplikacja dla kierowców: mapa, zgłoszenia drogowe, alerty, dane fotoradarów oraz wirtualne CB.

## Uruchomienie

Projekt jest statyczną aplikacją PWA i może być wdrożony na Netlify lub innym hostingu HTTPS.

## Lokalizacja

AURIX korzysta z przeglądarkowego Geolocation API. Lokalizacja jest pobierana po świadomej akcji użytkownika. Aplikacja wymaga HTTPS i zgody przeglądarki.

## Brak kont kierowców

AURIX nie posiada logowania, profilu kierowcy, nazwy użytkownika ani zdjęcia profilowego. Ustawienia aplikacji są przechowywane lokalnie na urządzeniu.

## Dane współdzielone

Prawdziwe współdzielenie zgłoszeń, obecności kierowców, realtime CB oraz aktualizowana baza fotoradarów wymagają skonfigurowanego backendu i legalnie dostępnych źródeł danych. Frontend nie powinien udawać danych, których backend nie dostarcza.

## Języki

Polski, English, Nederlands, Deutsch, Lietuvių, Čeština, Slovenčina, Українська, Русский, Italiano, Español.
