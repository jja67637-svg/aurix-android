#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
if [ -z "${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}" ]; then
  echo 'ANDROID_SDK_ROOT/ANDROID_HOME is not set.'
  echo 'Run ./bootstrap-android-sdk.sh first, then export ANDROID_SDK_ROOT.'
  exit 1
fi
cd "$ROOT/android"
../gradlew clean assembleRelease
