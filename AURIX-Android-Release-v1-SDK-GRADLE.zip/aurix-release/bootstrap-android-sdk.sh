#!/usr/bin/env bash
set -euo pipefail
SDK_DIR="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-$HOME/Android/Sdk}}"
CMDLINE_VERSION="11076708"
mkdir -p "$SDK_DIR/cmdline-tools"
if [ ! -x "$SDK_DIR/cmdline-tools/latest/bin/sdkmanager" ]; then
  TMP="$(mktemp -d)"
  trap 'rm -rf "$TMP"' EXIT
  curl -fL --retry 3 -o "$TMP/tools.zip" "https://dl.google.com/android/repository/commandlinetools-linux-${CMDLINE_VERSION}_latest.zip"
  rm -rf "$TMP/latest" "$SDK_DIR/cmdline-tools/latest"
  mkdir -p "$TMP/latest"
  unzip -q "$TMP/tools.zip" -d "$TMP/latest"
  mv "$TMP/latest/cmdline-tools" "$SDK_DIR/cmdline-tools/latest"
fi
export ANDROID_SDK_ROOT="$SDK_DIR"
export PATH="$SDK_DIR/cmdline-tools/latest/bin:$SDK_DIR/platform-tools:$PATH"
yes | sdkmanager --licenses >/dev/null || true
sdkmanager "platform-tools" "platforms;android-36" "build-tools;36.0.0"
echo "Android SDK ready at $SDK_DIR"
