# AURIX Android Release Project

## Toolchain
- Android applicationId: `com.aurix.driver`
- compileSdk: 36
- targetSdk: 36
- minSdk: 24
- Java: 21
- Android Gradle Plugin: 8.13.0
- Gradle: 8.14.3

The project uses the current AURIX web assets from the v7 Auto Initial Refresh build and the native Android services from the AURIX Android project.

## Build on Linux/macOS
1. Install Java 21.
2. Run `./bootstrap-android-sdk.sh`.
3. Set `ANDROID_SDK_ROOT` to the SDK path printed by the script.
4. Run `./build-release.sh`.
5. Release APK: `android/app/build/outputs/apk/release/app-release.apk`

## Windows
Use WSL2 or Android Studio/SDK Manager. The Gradle/Android project itself is standard and can be opened from the `android` directory.

## Important
The repository intentionally does not embed a full Android SDK or Gradle distribution because these are large, machine-specific toolchains. The included bootstrap scripts install the exact SDK components and Gradle version required by this project.
