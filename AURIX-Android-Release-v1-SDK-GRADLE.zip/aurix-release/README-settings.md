# AURIX — ustawienia

AURIX nie posiada kont kierowców ani logowania. Ustawienia są zapisywane lokalnie na urządzeniu.

Dostępne ustawienia:
- głośność alertów,
- komunikaty głosowe,
- dźwięk alertów,
- sposób ostrzegania,
- typy zgłoszeń widoczne na mapie,
- typy zgłoszeń używane podczas jazdy,
- odległość ostrzegania,
- język aplikacji,
- lokalizacja,
- powiadomienia,
- mikrofon.

Dane lokalizacyjne są używane przez funkcje drogowe AURIX. Aplikacja nie wymaga nazwy użytkownika, zdjęcia profilowego, e-maila ani numeru telefonu.


## Funkcje Android APK

W wersji Android AURIX dostępne są dodatkowe ustawienia: GPS w tle, powiadomienia systemowe, ekran podczas jazdy, natywne audio, wibracje, uruchamianie GPS po starcie aplikacji, Android Auto oraz panel uprawnień Androida.

GPS w tle korzysta z natywnej usługi pierwszego planu typu `location`. Na Androidzie 14+ wymagane są odpowiednie uprawnienia lokalizacji i `FOREGROUND_SERVICE_LOCATION`; uruchomienie usługi jest wykonywane po akcji użytkownika w aplikacji.
