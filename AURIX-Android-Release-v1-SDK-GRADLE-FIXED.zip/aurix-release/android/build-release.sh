#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
./gradlew --no-daemon clean assembleRelease
echo
echo "APK: app/build/outputs/apk/release/app-release.apk"
